﻿=== Age of Empires II DE Cursor Set ===

By: Anonymous Me

Download: http://www.rw-designer.com/cursor-set/aoe2decursors

Author's description:

I was inspired to post these by Fornacott's "Age of Empires II Cursors" set (check out that set!  It has other cursors this set does not have), since the definitive edition added new cursors to that are not yet represented on this site.
 

This cursor set was inspired by the in-game cursors of Age of Empires 2 Definitive Edition.
All rights reserved


==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.