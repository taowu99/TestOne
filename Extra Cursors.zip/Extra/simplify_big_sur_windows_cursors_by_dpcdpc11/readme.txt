================== Simplify Big Sur Cursors ==================

AUTHOR: deviantart.com/dpcdpc11
For a better visual experience, use the cursors along side my Windows Themes: https://gumroad.com/dpcdpc11

INSTALLATION INSTRUCTIONS:
- after unpacking the archive, navigate to each folder and find the _install.inf file 
- Right Click on the _install.inf file and select Install from the Right Click Menu
- now just go to Contro Panel > Mouse > Pointers and from the Scheme drop-down menu choose the new Cursor scheme installed
- make sure the option "Enable pointer shadow" is disabled since the cursors have their own shadow baked in
- and finally hit Apply or Ok and you're good to go!

ENJOY AND THANK YOU FOR DOWNLOADING!