﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BWP.WinFormControl;
using PoultryButcheryClient.BO.BO.Bill;
using PoultryButcheryClient.BO.Utils;
using PoultryButcheryClient.BO.Utils.BillSync;

namespace WorkShopPack
{
    public partial class RePrintCodeForm : Form
    {

        private WorkShopRecord dmo;
        public RePrintCodeForm()
        {
            InitializeComponent();
            dmo = null;
        }

    

        private void uTextBoxWithPad1_TextChanged(object sender, EventArgs e)
        {
            var mFieldText = uTextBoxWithPad1.Text;

            LoadDmoInfo(mFieldText);
        }

        private void LoadDmoInfo(string mFieldText)
        {
            long id = default(long);
            if (long.TryParse(mFieldText, out id))
            {

                dmo = WorkShopRecordRpc.LoadDmo(id);
                if (dmo != null)
                {
                    label1.Text = dmo.Goods_Name;
                    label2.Text = dmo.BarCode;
                    label3.Text = (dmo.Number ?? 0).ToString();
                    label4.Text = (dmo.CreateTime).ToString();
                }
                else
                {
                    MessageBox.Show("未找到当前单据");
                }


            }

        }

 

        //打码

        private void button1_Click(object sender, EventArgs e)
        {

            PrintGoods(dmo);
        }


        private void PrintGoods(WorkShopRecord entity)
        {
            var prConfig = ButcherAppContext.Context.PrConfig;

            if (prConfig.PrintType == 0)
            {

                PrintAPI.B_GetUSBBufferLen();
                PrintAPI.B_EnumUSB(new byte[128]);
                PrintAPI.B_CreateUSBPort(1);
                PrintAPI.B_Prn_Text_TrueType(255, 15, 38, "宋体", 1, 700, 0, 0, 0, "C1", entity.Goods_Name);
                PrintAPI.B_Bar2d_QR(40, 75, 2, 12, 'M', 'A', 0, 0, 0, entity.BarCode);
                var y = 50;
                var cIdx = 1;

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("存货编码：{0}", entity.Goods_Code));

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("数量：{0}", 1));

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("重量：{0}", entity.Number));

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("打印时间：{0}", DateTime.Now.ToString("yyyy/MM/dd HH:mm")));

                PrintAPI.B_Set_Direction('B');
                PrintAPI.B_Print_Out(1);
                PrintAPI.B_ClosePrn();
            }
            else if (prConfig.PrintType == 1)
            {
                var TemString = File.ReadAllText(prConfig.TemplateRecordName);
                var str = TemString.Replace("{0}", entity.BarCode).Replace("{1}", entity.Goods_Name).Replace("{2}", string.Format("序号:{0}", entity.ID)).Replace("{3}", "数量:1")
                    .Replace("{4}", string.Format("重量:{0:F}", entity.Number)).Replace("{5}", string.Format("打印时间:{0}", DateTime.Now.ToString("yyyy/MM/dd HH:mm")));
                ZebraPrintHelper.SendStringToPrinter(prConfig.PrintName, str);
            }

        }

    }
}
