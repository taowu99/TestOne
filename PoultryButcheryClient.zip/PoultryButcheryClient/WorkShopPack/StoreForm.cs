﻿using PoultryButcheryClient.BO.BO.BaseInfo;
using PoultryButcheryClient.BO.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PoultryButcheryClient.BO;

namespace WorkShopPack
{
//    public delegate void BackEvent(string s, long id);
    public partial class StoreForm : Form
    {
        public event BackEvent backEvent;

        private List<Store> mStoreNoList;
        public StoreForm()
        {
            InitializeComponent();

            InitStoreBaseInfo();

            InitStoreButtons();

        }

        private void InitStoreButtons()
        {
            foreach (var store in mStoreNoList)
            {
                var btn = CreateStoreBtn(store);
               flowLayoutPanel1.Controls.Add(btn);
            }
        }

        private Button CreateStoreBtn(Store store)
        {
            var btn = new Button() { Text = store.Name };
            btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            btn.Size = new System.Drawing.Size(80, 50);
            btn.UseVisualStyleBackColor = true;
            btn.Click += StoreBtn_Click;
            btn.Tag = store.ID;
            return btn;
        }

        private void StoreBtn_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            
            if (backEvent != null)
            {
//                backEvent(btn.Text, Convert.ToInt64(btn.Tag));
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void InitStoreBaseInfo()
        {
            mStoreNoList = BaseInfoRpcUtil.GetStoreBaseInfo();
    
        }
    }
}
