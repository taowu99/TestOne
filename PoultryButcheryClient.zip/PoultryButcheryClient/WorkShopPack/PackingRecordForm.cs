﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PoultryButcheryClient.BO.BO.Bill;
using PoultryButcheryClient.BO.Utils.BillSync;

namespace WorkShopPack
{
 
    public partial class PackingRecordForm : Form
    {

        private List<WorkShopRecord> mWorkShopRecords;
        private long mGoodsID;
        public PackingRecordForm(long goodsId)
        {
            mGoodsID = goodsId;
            InitializeComponent();
        }
        private void PackingRecordForm_Load(object sender, EventArgs e)
        {

            mWorkShopRecords = WorkShopRecordRpc.GetCompletedBillList();
            if (mGoodsID == 0)
            {
                allRecordBtn_Click(null, null);
            }
            else
            {
                nowRecordBtn_Click(null, null);
            }

        }


        private void closeBtn_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void nowRecordBtn_Click(object sender, EventArgs e)
        {
            nowRecordBtn.Enabled = false;
            allRecordBtn.Enabled = true;
            dataGridView1.Rows.Clear();
            var detail = mWorkShopRecords.Where(x => x.Goods_ID == mGoodsID);
            
            if (detail != null && detail.Count() > 0)
            {
                var first = detail.First();
                dataGridView1.Rows.Add(first.Goods_Name, detail.Sum(x=> x.SecondNumber??0), detail.Sum(x=> x.Number??0), detail.Sum(x=> x.SecondNumber2??0));
            }

  

        }

        private void allRecordBtn_Click(object sender, EventArgs e)
        {
            nowRecordBtn.Enabled = true;
            allRecordBtn.Enabled = false;
            dataGridView1.Rows.Clear();
            var group = mWorkShopRecords.GroupBy(x => new { x.Goods_ID, x.Goods_Name});
            foreach (var item in group)
            {
                dataGridView1.Rows.Add(item.Key.Goods_Name, item.Sum(x => x.SecondNumber ?? 0), item.Sum(x => x.Number ?? 0), item.Sum(x => x.SecondNumber2 ?? 0));
            }

   

        }


    }
}
