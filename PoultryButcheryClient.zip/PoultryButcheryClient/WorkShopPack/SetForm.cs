﻿using PoultryButcheryClient.BO.BO.BaseInfo.ClientGoodsSet_;
using PoultryButcheryClient.BO.Utils;
using PoultryButcheryClient.BO.Utils.BillSync;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Windows.Forms;
using System.Windows.Navigation;

namespace WorkShopPack
{
    public partial class SetForm : Form
    {


        public readonly static string mLocalClientGoodsFileName = "LocalClientGoodsList.xml";
        private Button selectedTopBtn;
        private Button selectedLeftBtn;
        private Dictionary<long?, List<Button>> AllGoodsButton;//左边一般的数据
        private Dictionary<DateTime?, List<Button>> AllProdNotiButtons;
        private DateTime? currentDate;//存储当前的时间
        private List<ClientGoodsSet> mClientGoodsSet;

        private string mFromProduceNoti = "from生产通知单";





        public SetForm()
        {
            InitializeComponent();
            InitSomeThing();
            InitTopButtons();
        }



        private void InitSomeThing()
        {
            AllGoodsButton = new Dictionary<long?, List<Button>>();
            AllProdNotiButtons = new Dictionary<DateTime?, List<Button>>();
            mClientGoodsSet = ClientGoodsSetBaseSync.GetClientGoodsSetList();
      

            var local = XmlUtil.DeserializeFromFile<List<ClientGoodsSet>>(mLocalClientGoodsFileName);
            if (local != null)
            {
                foreach (var goods in mClientGoodsSet)
                {
                    var loaclDetail = local.FirstOrDefault(x => x.Name == goods.Name);
                    foreach (var one in goods.Details)
                    {
                        if (loaclDetail != null)
                        {
                            if (loaclDetail.Details.Any(x => x.Goods_ID == one.Goods_ID)) { one.isSelectd = true; }
                        }
                    }
                }
            }
            currentDate = null;
            uDatePicker1.Text = DateTime.Today.ToString("yyyy/MM/dd");//设置时间改变时 会调用方法，应该放在和本地数据合并 之后
        }

        private void InitTopButtons()
        {
            foreach (var one in mClientGoodsSet.Where(x=> x.Name != mFromProduceNoti))
            {
                var btn = CreateTopButton(one.Name);
                topFlowLayoutPanel.Controls.Add(btn);

            }
        }
        private void InitProdNotiButton()
        {
            var date = uDatePicker1.Date;
            if (date == null)
            {
                return;
            }
            if (date == currentDate)
            {
                return;
            }
            currentDate = date;
            prodNotiFlowLayoutPanel.Controls.Clear();
            List<Button> partiBtns = null;
    
            if (AllProdNotiButtons.ContainsKey(date))
            {
                partiBtns = AllProdNotiButtons[date];
            }
            else
            {
                var data = mClientGoodsSet.FirstOrDefault(x => x.Name == mFromProduceNoti);
                if (data != null)
                {
                    var details = data.Details.Where(x => x.CompletedDate >= uDatePicker1.Date).ToList();

                    partiBtns = CreateGoodsBtn(details);
                }

            }
            if (partiBtns != null)
            {
                AllProdNotiButtons[date] = partiBtns;

                foreach (var goodsBtn in partiBtns)
                {

                    prodNotiFlowLayoutPanel.Controls.Add(goodsBtn);
                }
            } 

        }


        private Button CreateTopButton(string text)
        {
            var btn = new Button() { Text = text };
            btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            btn.Name = text;
            btn.Size = new System.Drawing.Size(150, 60);
            btn.Text = text;
            btn.UseVisualStyleBackColor = true;
            btn.Click += BtnTop_Click;
            return btn;
        }

        private Button CreateLeftButton(long?ID, string text)
        {
            var btn = new Button() { Text = text };
            btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            btn.Name = text;
            btn.Size = new System.Drawing.Size(150, 60);
            btn.Text = text;
            btn.Tag = ID;
            btn.UseVisualStyleBackColor = true;
            btn.Click += BtnLeft_Click;
            return btn;
        }

 

        private void BtnTop_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;

            if (selectedTopBtn != null)
            {
                selectedTopBtn.BackColor = DefaultBackColor;
            }
            btn.BackColor = Color.Aqua;
            selectedTopBtn = btn;
            goodFlowLayoutPanel.Controls.Clear();
            leftFlowLayoutPanel.Controls.Clear();
            var data = mClientGoodsSet.First(x => x.Name == btn.Text);

            if (data != null)
            {
                var items = data.Details.GroupBy(x => new {x.GoodsProperty_ID, x.GoodsProperty_Name});
                foreach (var item in items)
                {
                    var goodsBtn = CreateLeftButton(item.Key.GoodsProperty_ID ,item.Key.GoodsProperty_Name);
                    leftFlowLayoutPanel.Controls.Add(goodsBtn);
                }
            }


        }

        private void BtnLeft_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;

            if (selectedLeftBtn != null)
            {
                selectedLeftBtn.BackColor = DefaultBackColor;
            }
            btn.BackColor = Color.Aqua;
            selectedLeftBtn = btn;
            goodFlowLayoutPanel.Controls.Clear();
            var tag = btn.Tag as long?;

            List<Button> partiBtns = null;
            var data = mClientGoodsSet.First(x => x.Name == selectedTopBtn.Text);
            if (AllGoodsButton.ContainsKey(tag))
            {
                partiBtns = AllGoodsButton[tag];
            }
            else
            {
                var details = data.Details.Where(x => x.GoodsProperty_ID == tag).ToList();

                partiBtns = CreateGoodsBtn(details);
            }
            if (partiBtns != null)
            {
                AllGoodsButton[tag] = partiBtns;

                foreach (var goodsBtn in partiBtns)
                {
  
                    goodFlowLayoutPanel.Controls.Add(goodsBtn);
                }
            } 
        }

        private List<Button> CreateGoodsBtn(List<ClientGoodsSet_Detail> details)
        {
            if (details == null)
                return null;
            var list = new List<Button>();

            foreach (var one in details)
            {
                var btn = new Button() { Text = one.Goods_Name };
                btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                btn.Name = one.Goods_Name;
                btn.Size = new System.Drawing.Size(150, 60);
                btn.Tag = one;
                btn.UseVisualStyleBackColor = true;
                var color = one.isSelectd ? Color.Aqua : DefaultBackColor;
                btn.BackColor = color;
                btn.Click += BtnGoods_Click;
                list.Add(btn);
            }

            return list;
        }

        private void BtnGoods_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            var tag = btn.Tag as ClientGoodsSet_Detail;
            tag.isSelectd = !tag.isSelectd;
            var color = tag.isSelectd ? Color.Aqua : DefaultBackColor;
            btn.BackColor = color;

        }

        //确定按钮
        private void button1_Click(object sender, EventArgs e)
        {
            var list = new List<ClientGoodsSet>();
            foreach (var one in mClientGoodsSet)
            {
                var clentGood = new ClientGoodsSet();
                clentGood.Name = one.Name;
                foreach (var good in one.Details)
                {
                    if (good.isSelectd) 
                    {
                        clentGood.Details.Add(good);
                    }

                }
                list.Add(clentGood);

            }
            XmlUtil.SerializerObjToFile(list, mLocalClientGoodsFileName);
            DialogResult = DialogResult.OK;
            Close();
        }

        private void uDatePicker1_TextChanged(object sender, EventArgs e)
        {
 
            InitProdNotiButton();

        }

 

    }
}
