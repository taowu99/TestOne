﻿namespace WorkShopPack
{
    partial class PackingRecordForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.allRecordBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            this.nowRecordBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.辅数量 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.重量 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.袋数 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.allRecordBtn);
            this.splitContainer1.Panel1.Controls.Add(this.closeBtn);
            this.splitContainer1.Panel1.Controls.Add(this.nowRecordBtn);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Size = new System.Drawing.Size(1357, 545);
            this.splitContainer1.SplitterDistance = 66;
            this.splitContainer1.TabIndex = 1;
            // 
            // allRecordBtn
            // 
            this.allRecordBtn.Location = new System.Drawing.Point(137, 3);
            this.allRecordBtn.Name = "allRecordBtn";
            this.allRecordBtn.Size = new System.Drawing.Size(117, 45);
            this.allRecordBtn.TabIndex = 2;
            this.allRecordBtn.Text = "全部记录";
            this.allRecordBtn.UseVisualStyleBackColor = true;
            this.allRecordBtn.Click += new System.EventHandler(this.allRecordBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeBtn.BackColor = System.Drawing.Color.Red;
            this.closeBtn.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.closeBtn.Location = new System.Drawing.Point(1231, 12);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(103, 45);
            this.closeBtn.TabIndex = 1;
            this.closeBtn.Text = "关闭";
            this.closeBtn.UseVisualStyleBackColor = false;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // nowRecordBtn
            // 
            this.nowRecordBtn.Location = new System.Drawing.Point(3, 4);
            this.nowRecordBtn.Name = "nowRecordBtn";
            this.nowRecordBtn.Size = new System.Drawing.Size(117, 45);
            this.nowRecordBtn.TabIndex = 0;
            this.nowRecordBtn.Text = "当前记录";
            this.nowRecordBtn.UseVisualStyleBackColor = true;
            this.nowRecordBtn.Click += new System.EventHandler(this.nowRecordBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeight = 40;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.名称,
            this.辅数量,
            this.重量,
            this.袋数});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.Size = new System.Drawing.Size(1357, 475);
            this.dataGridView1.TabIndex = 2;
            // 
            // 名称
            // 
            this.名称.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.名称.HeaderText = "名称";
            this.名称.MinimumWidth = 120;
            this.名称.Name = "名称";
            this.名称.ReadOnly = true;
            // 
            // 辅数量
            // 
            this.辅数量.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.辅数量.HeaderText = "辅数量(箱数)";
            this.辅数量.MinimumWidth = 120;
            this.辅数量.Name = "辅数量";
            this.辅数量.ReadOnly = true;
            // 
            // 重量
            // 
            this.重量.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.重量.HeaderText = "重量(主数量)";
            this.重量.MinimumWidth = 100;
            this.重量.Name = "重量";
            this.重量.ReadOnly = true;
            // 
            // 袋数
            // 
            this.袋数.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.袋数.HeaderText = "袋数(辅数量II)";
            this.袋数.Name = "袋数";
            this.袋数.ReadOnly = true;
            // 
            // PackingRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 546);
            this.Controls.Add(this.splitContainer1);
            this.Name = "PackingRecordForm";
            this.Text = "车间包装记录";
            this.Load += new System.EventHandler(this.PackingRecordForm_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Button closeBtn;
        private System.Windows.Forms.Button nowRecordBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button allRecordBtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn 名称;
        private System.Windows.Forms.DataGridViewTextBoxColumn 辅数量;
        private System.Windows.Forms.DataGridViewTextBoxColumn 重量;
        private System.Windows.Forms.DataGridViewTextBoxColumn 袋数;
    }
}