﻿using PoultryButcheryClient.BO.BO.BaseInfo;
using PoultryButcheryClient.BO.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WorkShopPack
{
    public delegate void BackEvent(string s);
    public partial class PlanNoForm : Form
    {
        public event BackEvent backEvent;

        private List<PlanNoBaseInfo> mPlanNoList;
        public PlanNoForm()
        {
            InitializeComponent();

            InitPlanBaseInfo();

            InitPlanButtons();

        }

        private void InitPlanButtons()
        {
            foreach (var planNo in mPlanNoList)
            {
               var btn = CreatePlanNoBtn(planNo);
               flowLayoutPanel1.Controls.Add(btn);
            }
        }

        private Button CreatePlanNoBtn(PlanNoBaseInfo planNo)
        {
            var btn = new Button() { Text = planNo.Name };
            btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            btn.Size = new System.Drawing.Size(80, 50);
            btn.UseVisualStyleBackColor = true;
            btn.Click += PlanNoBtn_Click;
            return btn;
        }

        private void PlanNoBtn_Click(object sender, EventArgs e)
        {
            var btn = sender as Button;
            
            if (backEvent != null)
            {
                backEvent(btn.Text);
            }
            DialogResult = DialogResult.OK;
            Close();
        }

        private void InitPlanBaseInfo()
        {
            mPlanNoList = BaseInfoRpcUtil.GetPlanNoBaseInfo();
            var normal = new PlanNoBaseInfo();
            normal.Name = DateTime.Today.ToString("yyyyMMdd");
            if (!mPlanNoList.Any(x => x.Name == normal.Name))
            {
                mPlanNoList.Add(normal);
            }
        }
    }
}
