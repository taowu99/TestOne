﻿using BWP.WinFormControl;
using PoultryButcheryClient.BO.BO.BaseInfo.ClientGoodsSet_;
using PoultryButcheryClient.BO.BO.Bill;
using PoultryButcheryClient.BO.Utils;
using PoultryButcheryClient.BO.Utils.BillSync;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Xml.Linq;


namespace WorkShopPack
{
    public partial class MainForm : Form, IAfterLoginForm
    {
        public delegate void ProcessDelegate();  
        enum PrintMode
        {
            自动模式 = 0,
            手动模式 = 1

        }

        enum PrinButtonState
        {
            开始 = 0,//自动模式下
            暂停 = 1,//自动模式下
            打码 = 2 //手动模式下
            

        }
        static object locker = new object();
        private Dictionary<string, List<Button>> AllGoodsButton;
        private bool flag = true;
        private List<ClientGoodsSet> mClientGoodsSet;

        private ZebraUSBPrint printHelper;
//        private ZebraComPrint printHelper;
        private ProcessDelegate addGoodsDelegate;

        private string chaCheBarCode;
        private List<WorkShopRecord> currentBills;
        private Button mSelectedButton;

        private PrintMode printMode;
        private PrinButtonState printButtonState;


        private string TemString;//斑马打印机的模板文件
        private PrintConfig prConfig;
//        private Thread backThread;

        public MainForm()
        {
            InitializeComponent();

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            InitSomeThing();
            prConfig = ButcherAppContext.Context.PrConfig;
            if (prConfig.PrintType == 1)
            {
                TemString = File.ReadAllText(prConfig.TemplateRecordName);
            }
            printMode = PrintMode.自动模式;
            printButtonState = PrinButtonState.开始;
            addGoodsDelegate = new ProcessDelegate(AddNewGoods);
            
            var speed = prConfig.PrintSpeed ?? 0;
            if (speed == 0)
            {
                speed = 5;
            }
            timer1.Interval = speed * 1000;

            printHelper = new ZebraUSBPrint(prConfig.PrintName);
//            printHelper.Open();
//            printHelper = new ZebraComPrint(prConfig.ComPort);
            var l = printHelper.GetPnpDeviceID();
            var sw = File.AppendText("log.txt");
            sw.WriteLine("当前设备的uuid " + string.Join( "|", l));
            sw.Close();
            bool b = printHelper.Open();
            if (!b)
            {
                 throw  new Exception("COM端口连接打印机失败！！");
            }

        }
        private void CreateOperatePanel()
        {
           
            foreach (var item in mClientGoodsSet)
            {
 
                var details = item.Details;

                List<Button> partiBtns = null;
                if (AllGoodsButton.ContainsKey(item.Name))
                {
                    partiBtns = AllGoodsButton[item.Name];
                }
                else
                {
                    var data = mClientGoodsSet.First(x => x.Name == item.Name);
                    partiBtns = CreateGoodsBtn(data);
                }
                if (partiBtns != null)
                {
                    AllGoodsButton[item.Name] = partiBtns;
                    foreach (var goodBtn in partiBtns)
                    {

                        goodsFlowLayoutPanel.Controls.Add(goodBtn);
                    }
                }



            }
 
        }



 

        private List<Button> CreateGoodsBtn(ClientGoodsSet allGoods)
        {
            if (allGoods == null)
                return null;
            var list = new List<Button>();
            foreach (var one in allGoods.Details)
            {
                var btn = new Button() { Text = one.Goods_Name };
                btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
                btn.Name = one.Goods_Name;
                btn.Size = new System.Drawing.Size(200, 80);
                btn.Tag = one;
                btn.UseVisualStyleBackColor = true;
                btn.Click += BtnGoods_Click;
                list.Add(btn);
            }
    
            return list;
        }

        private void BtnGoods_Click(object sender, EventArgs e)
        {
            //首先判断当前 的后台线程是否在自动打印

   
            if (timer1.Enabled)
            {
                MessageBox.Show("当前打印机正在打码，请暂停之后切换存货");
                return;
            }



            //先判断当前存货是否为当前选中的 存货
            var btn = sender as Button;
            var goodsInfo = btn.Tag as ClientGoodsSet_Detail;
            var hasChangeGoods = false;//判断是否切换了 存货 如果切换则重新从数据库中加载
            if (mSelectedButton != null)
            {
                DialogResult result = MessageBox.Show("是否切换到存货" + goodsInfo.Goods_Name + "？", "提示", MessageBoxButtons.OKCancel);
                if (result == DialogResult.OK)
                {
                    hasChangeGoods = true;
                    // 如果确实是 点击切换
                    mSelectedButton.BackColor = DefaultBackColor;
                    mSelectedButton.Enabled = true;
                    btn.Enabled = false;
                    btn.BackColor = Color.Aqua;
                    mSelectedButton = btn;
                }             
   
            }
            else
            {
                hasChangeGoods = true;
                btn.Enabled = false;
                btn.BackColor = Color.Aqua;
                mSelectedButton = btn;
            }

            beginBtn.Enabled = true;
            if (hasChangeGoods)
            {
                ReloadTitle(goodsInfo);
                var goodList = WorkShopRecordRpc.GetUnCompletedList(goodsInfo.Goods_ID);
                if (goodList != null && goodList.Count > 0)
                {

                    ReloadUnComPleted(goodList);
                }
                else
                {
                    currentBills.Clear();
                    dataGridView1.Rows.Clear();
//                    chaCheBarCode = CreateCarBarCode(goodsInfo.Goods_Name);
                }

            }
        }


        

        private void beginBtn_Click(object sender, EventArgs e)
        {
            var stand = Convert.ToInt64(deafultNumberLabel.Text);
            var diff = stand - currentBills.Count;
            if (diff<=0)
            {
                MessageBox.Show("已超过标准箱数");
                return;

            }


            //点击开始 执行任务
            if (printMode == PrintMode.手动模式)
            {

                printButtonState = PrinButtonState.打码;

                AddNewGoods();
            }
            else
            {
                //自动模式
                //判断当前状态
                if (printButtonState == PrinButtonState.开始)
                {

//                    backThread = new Thread(AutomaticPrint);
//                    backThread.IsBackground = true;
//                    backThread.Start(diff);
                    flag = true;
                    timer1.Enabled  = true;
                    
                    printButtonState = PrinButtonState.暂停;



                }
                else if (printButtonState == PrinButtonState.暂停)
                {

                    timer1.Enabled = false;
                    printButtonState = PrinButtonState.开始;
                }

            }


            beginBtn.Text = printButtonState.ToString();

        }








        
        //加载原来的数据
        private void ReloadUnComPleted(List<WorkShopRecord> goodList)
        {
            var first = goodList.First();
            currentBills = goodList;
            dataGridView1.Rows.Clear();
            chaCheBarCode = first.ChaCarBoardCode;

            chaCarBarCodeLabel.Text = chaCheBarCode;
            foreach (var item in currentBills)
            {
                dataGridView1.Rows.Insert(0, dataGridView1.RowCount + 1, item.BarCode, item.Goods_Name, item.Goods_Spec, 1, item.Number, chaCheBarCode);
            }
            ReloadTotalInfo();
        }

    

        //点击 存货时添加数据
        private void AddNewGoods()
        {
            lock (locker)
            {
                StreamWriter sw = File.AppendText("log.txt");
                var goodsInfo = mSelectedButton.Tag as ClientGoodsSet_Detail;
                var detail = new WorkShopRecord();
                detail.BiaoShi = ButcherAppContext.Context.UserConfig.BiaoShi;
                detail.Goods_Name = goodsInfo.Goods_Name;
                detail.Goods_ID = goodsInfo.Goods_ID;
                detail.Goods_Spec = goodsInfo.Goods_Spec;
                detail.Goods_Code = goodsInfo.Goods_Code;
                detail.Goods_Spell = goodsInfo.Goods_Spell;
                detail.SecondNumber = 1;
                detail.Number = 1 * goodsInfo.Goods_MainUnitRatio;
                detail.PlanNumber = planNoButton.Text;
                var ratio = goodsInfo.Goods_SecondUnitII_MainUnitRatio ?? 0;

                detail.SecondNumber2 = ratio == 0 ? null : detail.Number / goodsInfo.Goods_SecondUnitII_MainUnitRatio;
                detail.ChaCarBoardCode = chaCheBarCode;
                detail.No = currentBills.Count + 1;

                sw.WriteLine("添加存货之前No" + detail.No+ DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + detail.No);
                sw.Close();
                currentBills.Add(detail);
                var result = WorkShopRecordRpc.Insert(detail);
                detail.ID = result.Item1;
                detail.BarCode = result.Item2;
                dataGridView1.Rows.Insert(0, dataGridView1.RowCount + 1, detail.BarCode, goodsInfo.Goods_Name, goodsInfo.Goods_Spec, 1, detail.Number, chaCheBarCode);
                ReloadTotalInfo();
                PrintGoods(detail, result.Item2);
                sw = File.AppendText("log.txt");
                sw.WriteLine("添加存货之后No" + detail.No + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + detail.No + "\n" + "-------------------------------------");
                sw.Close();
                var stand = goodsInfo.Goods_StandardSecondNumber??0;
                var diff = stand - currentBills.Count;
                flag = diff != 0;
            }
 
        }


        //更新中间的信息

        void ReloadTitle(ClientGoodsSet_Detail goodsInfo)
        {
            productLabel.Text = goodsInfo.Goods_Name;
            specLabel.Text = goodsInfo.Goods_Spec;
            goodNameLabel.Text = goodsInfo.Goods_Name;
            deafultNumberLabel.Text = (goodsInfo.Goods_StandardSecondNumber ?? 0).ToString();
            numberLabel1.Text = (goodsInfo.Goods_StandardSecondNumber??0).ToString();
            weightNumber1.Text = ((goodsInfo.Goods_StandardSecondNumber ?? 0) * (goodsInfo.Goods_MainUnitRatio ?? 0)).ToString();

            numberLabel2.Text = "";
            weightNumber2.Text = "";
            numberLabel3.Text = "";
            weightNumber3.Text = "";

        }
        private void ReloadTotalInfo()
        {
            var goodsInfo = mSelectedButton.Tag as ClientGoodsSet_Detail;
            var biaoZhunNumber = 0m;
            var biaoZhunWeight = 0m;
            if (goodsInfo != null)
            {
                biaoZhunNumber = goodsInfo.Goods_StandardSecondNumber ?? 0;
                biaoZhunWeight = (goodsInfo.Goods_StandardSecondNumber ?? 0) * (goodsInfo.Goods_MainUnitRatio ?? 0);
            }
            var completedNumber = currentBills.Sum(x => x.SecondNumber);
            var completedWeight = currentBills.Sum(x => x.Number);

            var unCompletedNumber = biaoZhunNumber - completedNumber;
            var unCompletedWeight = biaoZhunWeight - completedWeight;


            numberLabel2.Text = completedNumber.ToString();
            weightNumber2.Text = completedWeight.ToString();


            numberLabel3.Text = unCompletedNumber.ToString();
            weightNumber3.Text = unCompletedWeight.ToString();


        }




        private  void PrintGoods(WorkShopRecord entity, string code)
        {

            if (prConfig.PrintType == 0)
            {
             
                PrintAPI.B_GetUSBBufferLen();
                PrintAPI.B_EnumUSB(new byte[128]);
                PrintAPI.B_CreateUSBPort(1);
                PrintAPI.B_Prn_Text_TrueType(255, 15, 38, "宋体", 1, 700, 0, 0, 0, "C1", entity.Goods_Name);
                PrintAPI.B_Bar2d_QR(40, 75, 2, 12, 'M', 'A', 0, 0, 0, code);
                var y = 50;
                var cIdx = 1;

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("存货编码：{0}", entity.Goods_Code));

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("数量：{0}", 1));

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("重量：{0}", entity.Number));

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx), string.Format("打印时间：{0}", DateTime.Now.ToString("yyyy/MM/dd HH:mm")));

                PrintAPI.B_Set_Direction('B');
                PrintAPI.B_Print_Out(1);
                PrintAPI.B_ClosePrn();
            }
            else if (prConfig.PrintType == 1)
            {
                StreamWriter sw = File.AppendText("log.txt");
                sw.WriteLine("发送命令之前No" + entity.No+ DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + entity.No);
                var str = TemString.Replace("{0}", code).Replace("{1}", entity.Goods_Name).Replace("{2}", string.Format("序号:{0}", entity.No)).Replace("{3}", "数量:1")
                    .Replace("{4}", string.Format("重量:{0}", entity.Number)).Replace("{5}", string.Format("编号:{0}", entity.ID)).Replace("{6}", string.Format("打印时间:{0}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")));
//                ZebraPrintHelper.SendStringToPrinter(prConfig.PrintName, str);
//                ZebraPrintHelper.PrintWithCOM(str, prConfig.ComPort, false);

                bool b = printHelper.Open();
                if (!b)
                {
                    sw.WriteLine("打印的时候端口没打开----" + entity.No + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
                }
                printHelper.Write(str);
                string w = "发送命令之后No" + entity.No + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss") + entity.ID;
                sw.WriteLine(w);
                sw.Close();

            }
  
        }



        private void InitSomeThing()
        {
            AllGoodsButton = new Dictionary<string, List<Button>>();
            currentBills = new List<WorkShopRecord>();  
            mClientGoodsSet = XmlUtil.DeserializeFromFile<List<ClientGoodsSet>>(SetForm.mLocalClientGoodsFileName);
            mSelectedButton = null;
            goodsFlowLayoutPanel.Controls.Clear();
            if (mClientGoodsSet.Any())
            {
                CreateOperatePanel();
            }
            beginBtn.Enabled = false;

            //设置 仓库和计划号

//            storeButton.Text = ButcherAppContext.Context.UserConfig.Store_Name;
//            storeButton.Tag = ButcherAppContext.Context.UserConfig.Store_ID;
            planNoButton.Text = ButcherAppContext.Context.UserConfig.PlanNumber;
           
        }




        public Form Generate()
        {
            return this;
        }



        private void SpeciesConfig_Click(object sender, EventArgs e)
        {
            var f = new SetForm();
            if (f.ShowDialog() == DialogResult.OK)
            {
                InitSomeThing();
            }
        }


        private void endBtn_Click(object sender, EventArgs e)
        {
 

            if (timer1.Enabled)
            {
                MessageBox.Show("当前打印机正在打码，请暂停之后切换存货");
                return;
            }
            if (currentBills.Count <= 0)
            {
                MessageBox.Show("当前箱数不能为空");
                return;
                
            }
         
            var barCode = "";
            var result = WorkShopPackBillRpc.InsertPackBill(currentBills, out barCode);

            StreamWriter sw = File.AppendText("log.txt");
            string w = "*******一拍结束*********" + result.Item2 + "\n";
            sw.Write(w);
            sw.Close();
            PrintBillBarCode(result, barCode);
            currentBills.Clear();
            dataGridView1.Rows.Clear();




         }

        private  void PrintBillBarCode(Tuple<long, int> tuple, string code)
        {
            long id = tuple.Item1;
            var No = tuple.Item2;
         
            var goodsInfo = mSelectedButton.Tag as ClientGoodsSet_Detail;
            var title = string.Format("包装单{0}", id);
            var 序号 = string.Format("序号:{0}", No);
            var 箱数 = string.Format("箱数:{0}", currentBills.Count);
            var 总重量 = string.Format("总重量:{0}", currentBills.Sum(x => x.Number ?? 0));
            var 打印时间 = string.Format("打印时间:{0}", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));

            if (prConfig.PrintType == 0)
            {

                PrintAPI.B_GetUSBBufferLen();
                PrintAPI.B_EnumUSB(new byte[128]);
                PrintAPI.B_CreateUSBPort(1);
                PrintAPI.B_Prn_Text_TrueType(255, 15, 38, "宋体", 1, 700, 0, 0, 0, "C1", title);
                PrintAPI.B_Bar2d_QR(40, 75, 2, 12, 'M', 'A', 0, 0, 0, code);
                var y = 50;
                var cIdx = 1;
   
                if (goodsInfo != null)
                {
                    PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx),
                        string.Format("存货：{0}", goodsInfo.Goods_Name));
                }


                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx),
                    箱数);

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx),
                    总重量 );

                PrintAPI.B_Prn_Text_TrueType(300, y += 40, 32, "宋体", 1, 600, 0, 0, 0, "C" + (++cIdx),
                    打印时间 );

                PrintAPI.B_Set_Direction('B');
                PrintAPI.B_Print_Out(1);
                PrintAPI.B_ClosePrn();
            }
            else
            {
                var temp = File.ReadAllText(prConfig.TemplateBillName);
                var str = temp.Replace("{0}", code).Replace("{1}", title).Replace("{2}", goodsInfo.Goods_Name).Replace("{3}", 序号)
                    .Replace("{4}", 箱数)
                    .Replace("{5}", 总重量).Replace("{6}", 打印时间);
//                ZebraPrintHelper.SendStringToPrinter(prConfig.PrintName, str);
//                ZebraPrintHelper.PrintWithCOM(str, prConfig.ComPort, false);
                StreamWriter sw = File.AppendText("log.txt");

                bool b = printHelper.Open();
                if (!b)
                {
                    sw.WriteLine("打印的时候端口没打开----" +id + DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"));
                }
                printHelper.Write(str);



                string w = "*******打印一拍*********" + id + "\n";
                sw.Write(w);
                sw.Close();
            }
       
        }



        private void MainForm_KeyUp(object sender, KeyEventArgs e)
        {

        }
        private void planNo_Click(object sender, EventArgs e)
        {
            var f = new PlanNoForm();
            f.backEvent += ReloadPlanNumber;
            if (f.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void ReloadPlanNumber(string s)
        {

            planNoButton.Text = s;
        }



        private void store_Click(object sender, EventArgs e)
        {

            var f = new StoreForm();
//            f.backEvent += ReloadstoreInfro;
            if (f.ShowDialog() == DialogResult.OK)
            {

            }
        }



        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ButcherAppContext.Context.UserConfig.PlanNumber = planNoButton.Text;
            ButcherAppContext.Context.Save();
            //判断当前 后台线程是否为空

            if (timer1.Enabled)
            {
                timer1.Enabled = false;
            }
            timer1.Dispose();
            printHelper.Close();
        }

        
        private void packingRecord_Click(object sender, EventArgs e)
        {
            long goodID = 0;
            if (mSelectedButton != null)
            {
                var detail = mSelectedButton.Tag as ClientGoodsSet_Detail;
                goodID = detail.Goods_ID;
            }
            var f = new PackingRecordForm(goodID);
//            f.backEvent += ReloadstoreInfro;
            if (f.ShowDialog() == DialogResult.OK)
            {

            }
        }

        private void StateButton_Click(object sender, EventArgs e)
        {
      
            //当前打印模式为自动模式  
            if (printMode == PrintMode.自动模式)
            {
                if (timer1.Enabled)
                {
                    timer1.Enabled = false;
                }
  
                //将当前的打印模式设置为手动模式
                printMode = PrintMode.手动模式;
                //将当前的按钮状态设置为打码状态
                printButtonState = PrinButtonState.打码;
            }
            else if (printMode == PrintMode.手动模式) //当前打印模式为手动模式 
            {
                //将当前的打印模式设置为手动模式
                printMode = PrintMode.自动模式;
                //将当前的按钮状态设置为打码状态
                printButtonState = PrinButtonState.开始;

            }




            beginBtn.Text = printButtonState.ToString();
            StateButton.Text = printMode.ToString();

        }



        //补码 
        private void RePrintCodeClick(object sender, EventArgs e)
        {

            var f = new RePrintCodeForm();
//            f.backEvent += ReloadstoreInfro;
            if (f.ShowDialog() == DialogResult.OK)
            {

            }
             
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (flag)
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(addGoodsDelegate);
                }
                else
                {
                    AddNewGoods();
                }

            }
            else
            {
                ProcessDelegate changeState = delegate()
                {
                    printButtonState = PrinButtonState.开始;
                    beginBtn.Text = printButtonState.ToString();
                    timer1.Enabled = false;
                };
                if (beginBtn.InvokeRequired)
                {
                    beginBtn.Invoke(changeState);

                }
                else
                {
                    printButtonState = PrinButtonState.开始;
                    beginBtn.Text = printButtonState.ToString();
                    timer1.Enabled = false;
                }


            }

        }





    }
}
