﻿namespace StatisticalManual
{
  partial class AddSpecForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.btn1 = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.btn2 = new System.Windows.Forms.Button();
      this.btn3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button5 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.btnAdd = new System.Windows.Forms.Button();
      this.groupBox1.SuspendLayout();
      this.SuspendLayout();
      // 
      // btn1
      // 
      this.btn1.Location = new System.Drawing.Point(91, 57);
      this.btn1.Name = "btn1";
      this.btn1.Size = new System.Drawing.Size(74, 65);
      this.btn1.TabIndex = 0;
      this.btn1.UseVisualStyleBackColor = true;
      this.btn1.Click += new System.EventHandler(this.btnInput_Click);
      // 
      // label1
      // 
      this.label1.BackColor = System.Drawing.Color.Silver;
      this.label1.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.label1.Location = new System.Drawing.Point(192, 57);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(73, 65);
      this.label1.TabIndex = 1;
      this.label1.Text = "系";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // btn2
      // 
      this.btn2.Location = new System.Drawing.Point(290, 57);
      this.btn2.Name = "btn2";
      this.btn2.Size = new System.Drawing.Size(74, 65);
      this.btn2.TabIndex = 0;
      this.btn2.UseVisualStyleBackColor = true;
      this.btn2.Click += new System.EventHandler(this.btnInput_Click);
      // 
      // btn3
      // 
      this.btn3.Location = new System.Drawing.Point(386, 57);
      this.btn3.Name = "btn3";
      this.btn3.Size = new System.Drawing.Size(74, 65);
      this.btn3.TabIndex = 0;
      this.btn3.UseVisualStyleBackColor = true;
      this.btn3.Click += new System.EventHandler(this.btnInput_Click);
      // 
      // button4
      // 
      this.button4.BackColor = System.Drawing.Color.Red;
      this.button4.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button4.Location = new System.Drawing.Point(59, 20);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(74, 65);
      this.button4.TabIndex = 0;
      this.button4.Text = "红";
      this.button4.UseVisualStyleBackColor = false;
      this.button4.Click += new System.EventHandler(this.btnSelect_Click);
      // 
      // button5
      // 
      this.button5.BackColor = System.Drawing.Color.Yellow;
      this.button5.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button5.Location = new System.Drawing.Point(139, 20);
      this.button5.Name = "button5";
      this.button5.Size = new System.Drawing.Size(74, 65);
      this.button5.TabIndex = 0;
      this.button5.Text = "黄";
      this.button5.UseVisualStyleBackColor = false;
      this.button5.Click += new System.EventHandler(this.btnSelect_Click);
      // 
      // button6
      // 
      this.button6.BackColor = System.Drawing.Color.Lime;
      this.button6.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button6.Location = new System.Drawing.Point(219, 20);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(74, 65);
      this.button6.TabIndex = 0;
      this.button6.Text = "绿";
      this.button6.UseVisualStyleBackColor = false;
      this.button6.Click += new System.EventHandler(this.btnSelect_Click);
      // 
      // button7
      // 
      this.button7.BackColor = System.Drawing.Color.Blue;
      this.button7.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button7.Location = new System.Drawing.Point(299, 20);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(74, 65);
      this.button7.TabIndex = 0;
      this.button7.Text = "蓝";
      this.button7.UseVisualStyleBackColor = false;
      this.button7.Click += new System.EventHandler(this.btnSelect_Click);
      // 
      // button8
      // 
      this.button8.BackColor = System.Drawing.Color.White;
      this.button8.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.button8.Location = new System.Drawing.Point(379, 20);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(74, 65);
      this.button8.TabIndex = 0;
      this.button8.Text = "白";
      this.button8.UseVisualStyleBackColor = false;
      this.button8.Click += new System.EventHandler(this.btnSelect_Click);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.button5);
      this.groupBox1.Controls.Add(this.button4);
      this.groupBox1.Controls.Add(this.button6);
      this.groupBox1.Controls.Add(this.button8);
      this.groupBox1.Controls.Add(this.button7);
      this.groupBox1.Location = new System.Drawing.Point(12, 174);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(537, 100);
      this.groupBox1.TabIndex = 2;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "规格选择";
      // 
      // btnAdd
      // 
      this.btnAdd.Font = new System.Drawing.Font("宋体", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      this.btnAdd.Location = new System.Drawing.Point(196, 309);
      this.btnAdd.Name = "btnAdd";
      this.btnAdd.Size = new System.Drawing.Size(132, 55);
      this.btnAdd.TabIndex = 3;
      this.btnAdd.Text = "添加";
      this.btnAdd.UseVisualStyleBackColor = true;
      this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
      // 
      // AddSpecForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(550, 407);
      this.Controls.Add(this.btnAdd);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.btn3);
      this.Controls.Add(this.btn2);
      this.Controls.Add(this.btn1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "AddSpecForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "添加规格";
      this.groupBox1.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button btn1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Button btn2;
    private System.Windows.Forms.Button btn3;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button5;
    private System.Windows.Forms.Button button6;
    private System.Windows.Forms.Button button7;
    private System.Windows.Forms.Button button8;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Button btnAdd;
  }
}