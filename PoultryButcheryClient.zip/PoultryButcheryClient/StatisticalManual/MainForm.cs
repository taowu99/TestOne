﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BWP.WinFormControl;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using PoultryButcheryClient.BO.BO.Bill;
using PoultryButcheryClient.BO.BO.Bill.FrozenInStoreSetBillSync_;
using PoultryButcheryClient.BO.Utils;
using PoultryButcheryClient.BO.Utils.BillSync;

namespace StatisticalManual
{
  public partial class MainForm : Form, IMainInterface
  {

  
    private string mWorkshopCategory;

    private List<ManualInputControl> mManualInputList;//存放所有
    private ManualInput mSelectedManualInput;//记录选中的

    private List<ManualSet> mSelectedLocalManualSetList;//配置的

    //private string currentPlanNumber;

    public MainForm(string workshopCategoryName)
    {
      InitializeComponent();
      mWorkshopCategory = workshopCategoryName;
       
    }


    public InputType InputType { get { return InputType.Manual; }}
    public Form Generate()
    {
      return this;
    }

    private void button9_Click(object sender, EventArgs e)
    {

    }

    private void MainForm_Load(object sender, EventArgs e)
    {  


      InitControl();
    }

    void InitControl()
    {


        mSelectedLocalManualSetList = XmlUtil.DeserializeFromFile<List<ManualSet>>(SetForm.ManualSetListFileName).Where(x => x.IsSelected && x.WorkshopCategory_Name == mWorkshopCategory).ToList();
      mManualInputList = new List<ManualInputControl>();


      flowLayoutPanel1.Controls.Clear();
      //List<FrozenInStoreSetBill> list = FrozenInStoreSetBillSync.GetFrozenInStoreSetBillList(mWorkshopCategory);
      if (mSelectedLocalManualSetList.Count > 0)
      {
        CreateOperatePanel(mSelectedLocalManualSetList);
      }
    }

    void SetChangedSort(FlowLayoutPanel flowPanel)
    {
      foreach (ManualInputControl inputControl in flowPanel.Controls)
      {
        var childIndex = flowPanel.Controls.GetChildIndex(inputControl);
        var localManualSet = mSelectedLocalManualSetList.First(x => x.CalculateGoods_ID == inputControl.ManualInput.CalculateGoods_ID);
        localManualSet.Sort = childIndex;
      }
      XmlUtil.SerializerObjToFile(mSelectedLocalManualSetList, SetForm.ManualSetListFileName);
    }

    private void CreateOperatePanel(List<ManualSet> localSetList)
    {
      //Height=664  Width=1348
      var height = flowLayoutPanel1.Height;
      var width = flowLayoutPanel1.Width;
      //根据宽度Width判断要添加几个panel （配置表）
      //flowLayoutPanel1.Width - (list.Count*10) 为了中间留空,
      var list = localSetList.GroupBy(x => x.FrozenInStoreSet_Name).ToList();
      var perWidth = (width - list.Count * 10) / list.Count;
      for (int i = 0; i < list.Count; i++)
      {
        var groupBox = new GroupBox();
//        groupBox.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));

        //        panel.BorderStyle = BorderStyle.FixedSingle;
        groupBox.Text = list[i].Key;
        groupBox.Width = perWidth;
        groupBox.Height = height-10;
        groupBox.Click += GroupBox_Click; ;
        var flowPanel=new FlowLayoutPanel();
//        var flowPanel=new Panel();
        flowPanel.Dock = DockStyle.Fill;
        flowPanel.HorizontalScroll.Enabled = false;
        flowPanel.HorizontalScroll.Maximum = 0; // 把水平滚动范围设成0就看不到水平滚动条了
        flowPanel.AutoScroll = true;
        flowPanel.Click += FlowPanel_Click;
        flowPanel.AllowDrop = true;
        flowPanel.DragDrop += (sender, e) =>
        {
          ManualInputControl label = (ManualInputControl)e.Data.GetData(typeof(ManualInputControl));

          Point point = flowPanel.PointToClient(new Point(e.X, e.Y));
          Control control = flowPanel.GetChildAtPoint(point);
          if (control != null && label != control)
          {
            try
            {
              int index = flowPanel.Controls.GetChildIndex(control, false);
              flowPanel.Controls.SetChildIndex(label, index);
              flowPanel.Invalidate();

              //保存排序后的
              SetChangedSort(flowPanel);
            }
            catch (ArgumentException ex)
            {
            }
          }
        };
        flowPanel.DragEnter += (sender, e) =>
        {
          e.Effect = DragDropEffects.Copy;
        };
        foreach (var detail in list[i].ToList().Where(x=>x.Sort>=0).OrderBy(x=>x.Sort))
        {
          var m=new ManualInput();
            m.PlanNumber = detail.PlanNumber;
          m.CalculateGoods_ID = detail.CalculateGoods_ID??0;
          m.CalculateGoods_Name = detail.CalculateGoods_Name;
          m.CalculateSpec_Name = detail.CalculateSpec_Name;
          m.InputNumber =detail.DefaultNumber1;
          m.MainUnitRatio = detail.MainUnitRatio??0;
          m.SecondUnitII_MainUnitRatio = detail.SecondUnitII_MainUnitRatio ?? 0;
          m.Goods_ID = detail.Goods_ID ?? 0;
         
          var input=new ManualInputControl(m,BtnInput_Click);
          input.DisplayLable.MouseDown += (sender, e) =>
          {
            if (e.Button == MouseButtons.Left && e.Clicks == 1)
            {
              base.OnMouseDown(e);
              Label label = sender as Label;
              
              var control = label.Parent as ManualInputControl;
              if (control.BackColor != Color.Aqua)
              {
                control.BackColor = Color.Aqua;
                mSelectedManualInput = control.ManualInput;
                SetDefaultBackColorAll();
              }

              control.DoDragDrop(control, DragDropEffects.Copy);
            }
          };

          input.MouseDown += (sender, e) =>
          {
            if (e.Button == MouseButtons.Left && e.Clicks == 1)
            {
              base.OnMouseDown(e);
              ManualInputControl control = sender as ManualInputControl;
              control.DoDragDrop(control, DragDropEffects.All);
            }
          };
//          input.MouseDown += Input_MouseDown;
//          input.MouseMove += Input_MouseMove;
//          input.MouseLeave += Input_MouseLeave;
          flowPanel.Controls.Add(input);
          mManualInputList.Add(input);
        }
        groupBox.Controls.Add(flowPanel);
        flowLayoutPanel1.Controls.Add(groupBox);
      }
    }


    private void FlowPanel_Click(object sender, EventArgs e)
    {
      ClearSelected();
    }

    private void GroupBox_Click(object sender, EventArgs e)
    {
      //ClearSelected();
    }

    //点击存货
    private void BtnInput_Click(object sender, ManualInputEventArgu e)
    {
      if (e.IsButtonClick)
      {
        SetAllDefaultBackColor();
        HandoverRecordRpc.Insert(e.ManualInput, e.ManualInput.PlanNumber);
        mSelectedManualInput = null;
        SetAllDefaultBackColorDelay1S();
      }
      else
      {
        mSelectedManualInput = e.ManualInput;
        SetDefaultBackColorAll();
      }
      
    }


    void SetAllDefaultBackColorDelay1S()
    {
      Thread.Sleep(500);
      this.Invoke(new Action(SetAllDefaultBackColor));
    }

    void SetAllDefaultBackColor()
    {
      foreach (ManualInputControl control in mManualInputList)
      {
         control.BackColor = DefaultBackColor;
      }
    }

    void SetDefaultBackColorAll()
    {
      foreach (ManualInputControl control in mManualInputList)
      {
        if (mSelectedManualInput==null||control.ManualInput != mSelectedManualInput)
        {
          control.BackColor = DefaultBackColor;
        }
      }
    }

    private void btnOk_Click(object sender, EventArgs e)
    {
      if (mSelectedManualInput == null)
      {
        MessageBox.Show("没有选中存货");
        lblSecond2.BackColor = Color.Silver;
        return;
      }
      var record = new HandoverRecord();
      record.CalculateGoods_Name = mSelectedManualInput.CalculateGoods_Name;
        record.CalculateGoods_ID = mSelectedManualInput.CalculateGoods_ID;
      record.CalculateSpec_Name = mSelectedManualInput.CalculateSpec_Name;
      record.MainUnitRatio = mSelectedManualInput.MainUnitRatio;
      record.SecondUnitII_MainUnitRatio = mSelectedManualInput.SecondUnitII_MainUnitRatio;
      record.Goods_ID = mSelectedManualInput.Goods_ID;
        record.PlanNumber = mSelectedManualInput.PlanNumber;
      int number;
      if (int.TryParse(lblDisplayNumber.Text, out number))
      {
        //辅单位Ⅱ
        if (lblSecond2.BackColor == Color.Aqua)
        {
          record.IsSecondⅡ = true;
          record.SecondIINumber = number;
          lblSecond2.BackColor = Color.Silver;
        }
        else
        {
          record.IsSecondⅡ = false;
          record.InputNumber = number;
        }
        HandoverRecordRpc.Insert(record);
      }
      ClearSelected();

    }

    void ClearSelected()
    {
      mSelectedManualInput = null;
      SetDefaultBackColorAll();
      lblDisplayNumber.Text = "";
      lblSecond2.BackColor = Color.Silver;
    }

    private void lblDisplayNumber_Click(object sender, EventArgs e)
    {
      lblDisplayNumber.Text = "";
    }

    //设置
    private void btnSet_Click(object sender, EventArgs e)
    {
      var f=new SetForm(mWorkshopCategory);
      if (f.ShowDialog() == DialogResult.OK)
      {
          InitControl();
      }
    }

    private void btnInputNumber_Click(object sender, EventArgs e)
    {
      var number = (sender as Button).Text;
      if (lblDisplayNumber.Text.Length > 2)
      {
        return;
      }
      lblDisplayNumber.Text += number;
    }

    private void btnRecord_Click(object sender, EventArgs e)
    {
      string mCalculateGoodsName="";
      if (mSelectedManualInput != null)
      {
        mCalculateGoodsName = mSelectedManualInput.CalculateGoods_Name;
      }
      var f=new HandoverRecordForm(mCalculateGoodsName);
      f.ShowDialog();
    }

    private void lblSecond2_Click(object sender, EventArgs e)
    {
      if (lblSecond2.BackColor == Color.Silver)
      {
        lblSecond2.BackColor=Color.Aqua;
      }
      else
      {
        lblSecond2.BackColor = Color.Silver;
      }
    }

    private void button_MouseDown(object sender, MouseEventArgs e)
    {
      var btn = sender as Button;
      btn.BackColor=Color.Aqua;
    }

    private void button_MouseUp(object sender, MouseEventArgs e)
    {
      var btn = sender as Button;
      btn.BackColor = SystemColors.Control; ;
    }

    private void btnTiaoZheng_Click(object sender, EventArgs e)
    {
      if (mSelectedManualInput == null)
      {
        return;
      }
      var f=new TiaoZhengForm(mSelectedManualInput, mSelectedManualInput.PlanNumber);
      f.ShowDialog();
    }

    //计划号
    private void planNo_Click(object sender, EventArgs e)
    {

        var f = new PlanNoForm();
        f.backEvent += ReloadPlanNumber;
        if (f.ShowDialog() == DialogResult.OK)
        {

        }
    }

    void ReloadPlanNumber(string s)
    {

        if (mSelectedManualInput != null)
        {
            mSelectedManualInput.PlanNumber = s;
            var localManualSet =
                mSelectedLocalManualSetList.First(x => x.CalculateGoods_ID == mSelectedManualInput.CalculateGoods_ID);

            if (localManualSet != null)
            {
                localManualSet.PlanNumber = s;

            }
        }
        else
        {
            foreach (var item in mSelectedLocalManualSetList)
            {
                item.PlanNumber = s;
            }
            foreach (var item in mManualInputList)
            {
                item.ManualInput.PlanNumber = s;
            }
        }
        XmlUtil.SerializerObjToFile(mSelectedLocalManualSetList, SetForm.ManualSetListFileName);
     
    }
  }
}
