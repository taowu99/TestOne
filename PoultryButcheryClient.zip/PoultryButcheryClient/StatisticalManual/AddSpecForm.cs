﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PoultryButcheryClient.BO.Utils;

namespace StatisticalManual
{
  public partial class AddSpecForm : Form
  {
    public string GoodsSpec="";
    private Button mSelectInputButton;
    public AddSpecForm()
    {
      InitializeComponent();
    }

    private void btnInput_Click(object sender, EventArgs e)
    {
      mSelectInputButton=sender as Button;
      //ClearAllBackColor();
      mSelectInputButton.BackColor=Color.Aqua;
      mSelectInputButton.Text = "";


    }

    private void btnSelect_Click(object sender, EventArgs e)
    {
      if (mSelectInputButton == null)
      {
        return;
      }
      var btn = sender as Button;
      mSelectInputButton.Text = btn.Text;
      mSelectInputButton.BackColor = btn.BackColor;


    }

    void ClearAllBackColor()
    {
      btn1.BackColor=DefaultBackColor;
      btn2.BackColor=DefaultBackColor;
      btn3.BackColor=DefaultBackColor;
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      GoodsSpec = "";
      if (string.IsNullOrWhiteSpace(btn1.Text))
      {
        MessageBox.Show("请先选择第一个");
        return;
      }
      GoodsSpec = btn1.Text;
      if (!string.IsNullOrWhiteSpace(btn2.Text)||!string.IsNullOrWhiteSpace(btn3.Text))
      {
        GoodsSpec += "系";
      }
      if (!string.IsNullOrWhiteSpace(btn2.Text) )
      {
        GoodsSpec += btn2.Text;
      }
      if (!string.IsNullOrWhiteSpace(btn3.Text))
      {
        GoodsSpec += btn3.Text;
      }
      btnAdd.Enabled = false;
      BaseInfoRpcUtil.InsertCalculateSpec(GoodsSpec);
      DialogResult =DialogResult.OK;
      Close();
    }
  }
}
