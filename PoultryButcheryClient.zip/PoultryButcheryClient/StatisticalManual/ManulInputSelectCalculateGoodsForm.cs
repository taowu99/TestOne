﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BWP.WinFormControl;
using Forks.Utils;
using XmlUtil = PoultryButcheryClient.BO.Utils.XmlUtil;

namespace StatisticalManual
{
  public partial class ManulInputSelectCalculateGoodsForm : Form
  {
    private ManualInput mManualInput;
    public ManualSet ManualSet;
    public ManulInputSelectCalculateGoodsForm(ManualInput manualInput)
    {
      InitializeComponent();
      mManualInput = manualInput;
    }

    private void ManulInputSelectCalculateGoodsForm_Load(object sender, EventArgs e)
    {
      var mlist= XmlUtil.DeserializeFromFile<List<ManualSet>>(SetForm.ManualSetListFileName);
      var fenlei =mlist.First(x => x.CalculateGoods_Name == mManualInput.CalculateGoods_Name).CalculateCatalog_Name;
      foreach (ManualSet manualSet in mlist.Where(x=>x.IsSelected&&x.CalculateCatalog_Name==fenlei).ToList())
      {
        var btn=CreateButton(manualSet);
        flowLayoutPanel1.Controls.Add(btn);
      }
    }

    Button CreateButton(ManualSet set)
    {
      var btn=new Button();
      btn.Text = set.CalculateGoods_Name;
      btn.Width = 200;
      btn.Height = 100;
      btn.Font = new System.Drawing.Font("宋体", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      btn.UseVisualStyleBackColor = true;
      btn.Click += Btn_Click;
      btn.Tag = set;
      return btn;
    }

    private void Btn_Click(object sender, EventArgs e)
    {
      var btn = sender as Button;

      ManualSet = btn.Tag as ManualSet;
      DialogResult=DialogResult.OK;
      Close();
    }
  }
}
