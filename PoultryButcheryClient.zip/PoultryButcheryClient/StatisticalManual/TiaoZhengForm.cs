﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BWP.WinFormControl;
using PoultryButcheryClient.BO.BO.Bill;
using PoultryButcheryClient.BO.Utils.BillSync;

namespace StatisticalManual
{
  public partial class TiaoZhengForm : Form
  {
    private ManualInput mManualInput;
    private string mPlanNumber;

    private HandoverRecordForUi oldForUi;


    public TiaoZhengForm(ManualInput manualInput,string planNumber)
    {
      InitializeComponent();
      mManualInput = manualInput;
      mPlanNumber = planNumber;
    }

    private void TiaoZhengForm_Load(object sender, EventArgs e)
    {
      var uilist = HandoverRecordRpc.GetList(mManualInput.CalculateGoods_Name, mPlanNumber);
      if (uilist == null || uilist.Count == 0)
      {
        MessageBox.Show("没有对应的：" + mManualInput.CalculateGoods_Name + " 的交接记录");
        Close();
        return;
      }
      oldForUi = uilist[0];

      SetOldDefaultValue(oldForUi);
    }



    private void lblNewName_Click(object sender, EventArgs e)
    {
      var f = new ManulInputSelectCalculateGoodsForm(mManualInput);
      if (f.ShowDialog() == DialogResult.OK)
      {
        mManualSet = f.ManualSet;
        lblNewName.Text = mManualSet.CalculateGoods_Name;
      }
    }

    private ManualSet mManualSet;

    void SetNewDisplay(ManualSet manualSet)
    {

    }

    private void btnNumber_Click(object sender, EventArgs e)
    {
      txtNewRecordCount.Focus();
      var btn = sender as Button;
      SendKeys.Send("{" + btn.Text + "}");
    }

    private void button11_Click(object sender, EventArgs e)
    {
      txtNewRecordCount.Focus();
      SendKeys.Send("{BACKSPACE}");
    }

    private void txtNewRecordCount_TextChanged(object sender, EventArgs e)
    {
      if (string.IsNullOrWhiteSpace(txtNewRecordCount.Text))
      {
        SetOldDefaultValue(oldForUi);
        lblNewPanShu.Text = "";
        lblNewDaiShu.Text = "";
        lblNewWeight.Text = "";
      }
      if (mManualSet == null)
      {
        txtNewRecordCount.Text = "";
        return;
      }
      int inputCount;//车次
      if (int.TryParse(txtNewRecordCount.Text, out inputCount))
      {
        var oldCount = Convert.ToInt32(oldForUi.StrRecordCount);
        if (inputCount > oldCount)
        {
          MessageBox.Show("不能大于原始记录数");
          SendKeys.Send("{BACKSPACE}");
          return;
        }

        ResetDisplayValue(inputCount);

      }
    }


    private HandoverRecordForUi newNewForUi, newOldForUi;

    /// <summary>
    /// 
    /// </summary>
    /// <param name="inputCount"></param>
    private void ResetDisplayValue(int inputCount)
    {
      newOldForUi = new HandoverRecordForUi();
      newOldForUi.CalculateGoods_Name = oldForUi.CalculateGoods_Name;
      newOldForUi.CalculateGoods_ID = oldForUi.CalculateGoods_ID; 
      newOldForUi.Goods_ID = oldForUi.Goods_ID;

      newNewForUi = new HandoverRecordForUi();
      newNewForUi.CalculateGoods_Name = mManualSet.CalculateGoods_Name;
      newNewForUi.CalculateGoods_ID = mManualSet.CalculateGoods_ID; 
      newNewForUi.Goods_ID = mManualSet.Goods_ID ?? 0;

      int index = -1;
      for (int i = oldForUi.Details.Count - 1; i >= 0; i--)
      {
        var detail = oldForUi.Details[i];
        index++;
        if (index >= inputCount)
        {
          //放到原始的
          newOldForUi.Details.Add(detail);
        }
        else
        {
          //放到调整的
          var ndetail = new HandoverRecordDetailForUi();
          ndetail.InputNumber = detail.InputNumber;
          ndetail.MainUnitRatio = mManualSet.MainUnitRatio;

          var weight = (ndetail.InputNumber ?? 0) * (mManualSet.MainUnitRatio ?? 0);
          if (mManualSet.SecondUnitII_MainUnitRatio != 0)
          {
            var secondIINumber = weight / mManualSet.SecondUnitII_MainUnitRatio;
            if (secondIINumber != null)
            {
              ndetail.SecondIINumber = secondIINumber;
              //              lblNewDaiShu.Text = secondIINumber.Value.ToString("0.##");
            }
          }
          ndetail.Weight = weight;
          //          lblNewWeight.Text = number.ToString("0.##");

          newNewForUi.Details.Add(detail);
        }
      }

      SetNewDefaultValue(newNewForUi);
      SetOldDefaultValue(newOldForUi);
    }

    void SetNewDefaultValue(HandoverRecordForUi forUi)
    {

      lblNewPanShu.Text = forUi.StrInputNumber;
      lblNewDaiShu.Text = forUi.StrSecondIINumber;
      lblNewWeight.Text = forUi.StrWeight;


      //lblOldName.Text = forUi.CalculateGoods_Name;
      //lblOldPanShu.Text = forUi.StrInputNumber;
      //lblOldRecordCount.Text = forUi.StrRecordCount;
      //lblOldDaiShu.Text = forUi.StrSecondIINumber;
      //lblOldWeight.Text = forUi.StrWeight;
    }

    void SetOldDefaultValue(HandoverRecordForUi forUi)
    {
      lblOldName.Text = forUi.CalculateGoods_Name;
      lblOldPanShu.Text = forUi.StrInputNumber;
      lblOldRecordCount.Text = forUi.StrRecordCount;
      lblOldDaiShu.Text = forUi.StrSecondIINumber;
      lblOldWeight.Text = forUi.StrWeight;
    }

    private void button12_Click(object sender, EventArgs e)
    {
      button12.Enabled = false;
      if (!string.IsNullOrWhiteSpace(txtNewRecordCount.Text))
      {
        if (newNewForUi != null)
        {
          
          for (int i = 0; i < newNewForUi.Details.Count; i++)
          {
            var detail = newNewForUi.Details[i];

            //删除 新的次数
            HandoverRecordRpc.DeleteLastRecord(oldForUi.CalculateGoods_Name, mPlanNumber);

            //添加新的
            var record=new HandoverRecord();
            record.CalculateGoods_Name = mManualSet.CalculateGoods_Name;
            record.CalculateGoods_ID = mManualSet.CalculateGoods_ID;
            record.CalculateSpec_Name = mManualSet.CalculateSpec_Name;
            record.InputNumber = detail.InputNumber;
//            record.SecondIINumber = ;
            record.MainUnitRatio = mManualSet.MainUnitRatio;
            record.SecondUnitII_MainUnitRatio = mManualSet.SecondUnitII_MainUnitRatio;
            record.IsSecondⅡ = false;
            record.Weight = detail.Weight;
            record.Goods_ID = mManualSet.Goods_ID??0;
            record.PlanNumber = mPlanNumber;
            HandoverRecordRpc.Insert(record);
            Application.DoEvents();
          }
        }
      }
      button12.Enabled = true;
      DialogResult =DialogResult.OK;
      Close();

    }
  }
}
