﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BWP.WinFormControl;
using PoultryButcheryClient.BO.BO.BaseInfo;
using PoultryButcheryClient.BO.BO.Bill.FrozenInStoreSetBillSync_;
using PoultryButcheryClient.BO.Utils;
using PoultryButcheryClient.BO.Utils.BillSync;

namespace StatisticalManual
{
  public partial class SetForm : Form
  {

    public static readonly string ManualSetListFileName = "ManualSetList.xml";
    private string mWorkshopCategory;

    private List<ManualSet> mLocalManualSetList;

    private List<Button> mPinLei = new List<Button>();
    private List<Button> mFenLei = new List<Button>();
    private List<ManualSetControl> mGoods = new List<ManualSetControl>();
    private List<Button> mCalculateSpecs = new List<Button>();

    private ManualSet mSelectedManualSet;//记录选中的

    public SetForm(string workshopCategoryName)
    {
      InitializeComponent();
      mWorkshopCategory = workshopCategoryName;
    }

    //    void InitListSet()
    //    {
    //      var list=new List<ManualSet>();
    //      list.Add(new ManualSet(){CalculateCatalog_Name = "分类",CalculateGoods_ID = 1,CalculateGoods_Name = "存货",CalculateSpec_Name = "蓝",IsSelected = true});
    //      list.Add(new ManualSet(){CalculateCatalog_Name = "分类1",CalculateGoods_ID = 2,CalculateGoods_Name = "存货1",CalculateSpec_Name = "白",IsSelected = true});
    //
    //      XmlUtil.SerializerObjToFile(list, ManualSetListFileName);
    //    }

//    void InitLoaclSet()
//    {
//      var list = new List<LocalManualSet>();
//      list.Add(new LocalManualSet() { CalculateCatalog_Name = "分类", CalculateGoods_Name = "存货", CalculateSpec_Name = "蓝" });
//      list.Add(new LocalManualSet() { CalculateCatalog_Name = "分类", CalculateGoods_Name = "存货", CalculateSpec_Name = "蓝" });
//      XmlUtil.SerializerObjToFile(list, "");
//    }

    private void SetForm_Load(object sender, EventArgs e)
    {
      //这里需要同步后台更新 和本地进行合并
      InitmManualSetList();
      InitButtonLists();
      InitGuiGe();
    }

    private void InitmManualSetList()
    {
      //根据品类得到速冻入库配置
      var mFrozenInStoreSetBillList = FrozenInStoreSetBillSync.GetFrozenInStoreSetBillList(mWorkshopCategory);
      mLocalManualSetList = XmlUtil.DeserializeFromFile<List<ManualSet>>(ManualSetListFileName); 
      foreach (FrozenInStoreSetBill frozenInStoreSetBill in mFrozenInStoreSetBillList)
      {
        foreach (var frozenInStoreSetBillDetail in frozenInStoreSetBill.Details)
        {
          var localset = new ManualSet();
          localset.FrozenInStoreSet_Name = frozenInStoreSetBill.Name;
          localset.WorkshopCategory_Name = frozenInStoreSetBill.WorkshopCategory_Name;
          localset.CalculateCatalog_Name = frozenInStoreSetBillDetail.CalculateCatalog_Name;
          localset.CalculateGoods_Name = frozenInStoreSetBillDetail.CalculateGoods_Name;
         
          localset.MainUnitRatio = frozenInStoreSetBillDetail.MainUnitRatio;
          localset.SecondUnitII_MainUnitRatio = frozenInStoreSetBillDetail.SecondUnitII_MainUnitRatio;
          localset.DefaultNumber1 = frozenInStoreSetBillDetail.DefaultNumber1 ?? 0;
          localset.Goods_ID = frozenInStoreSetBillDetail.Goods_ID ?? 0;
          //根据存货名称
          localset.CalculateGoods_ID = frozenInStoreSetBillDetail.CalculateGoods_ID ;

          if (localset.CalculateGoods_Name.Contains("2KG腿肉丁3/6"))
          {

          }

          //          var fd = mLocalManualSetList.FirstOrDefault(x =>  x.CalculateGoods_Name == localset.CalculateGoods_Name);
          var fd = mLocalManualSetList.FirstOrDefault(x =>x.FrozenInStoreSet_Name==localset.FrozenInStoreSet_Name&& x.CalculateGoods_ID == localset.CalculateGoods_ID);

          if (fd == null)
          {
            mLocalManualSetList.Add(localset);
          }
          else
          {
            
            //更新其他信息
            fd.DefaultNumber1 = localset.DefaultNumber1;
            fd.MainUnitRatio = localset.MainUnitRatio;
            fd.SecondUnitII_MainUnitRatio = localset.SecondUnitII_MainUnitRatio;
            fd.FrozenInStoreSet_Name = localset.FrozenInStoreSet_Name;
            fd.CalculateCatalog_Name = localset.CalculateCatalog_Name;
            fd.WorkshopCategory_Name = localset.WorkshopCategory_Name;
            fd.CalculateGoods_ID = localset.CalculateGoods_ID;
            fd.CalculateGoods_Name = localset.CalculateGoods_Name;
            fd.Goods_ID = localset.Goods_ID;

            if (localset.CalculateGoods_Name.Contains("2KG腿肉丁3/6"))
            {

            }
          }
        }
      }

    }

    private void InitGuiGe()
    {
      mCalculateSpecs = new List<Button>();
      flpGuiGe.Controls.Clear();
      var list = BaseInfoRpcUtil.GetCalculateSpecs();
      foreach (CalculateSpec spec in list)
      {
        var btn = CreateGuiGeButton(spec.Name);
        mCalculateSpecs.Add(btn);
        flpGuiGe.Controls.Add(btn);
      }
    }

    Button CreateGuiGeButton(string text)
    {
      var btn = new Button();
      btn.Name = text;
      btn.Size = new System.Drawing.Size(75, 50);
      btn.Text = text;
      btn.UseVisualStyleBackColor = true;
      btn.Click += BtnGuiGe_Click;
      return btn;
    }

    private void BtnGuiGe_Click(object sender, EventArgs e)
    {
      var btn = sender as Button;
      //设置背景色
      foreach (var btnSpec in mCalculateSpecs)
      {
        if (btnSpec == btn)
        {
          if (btnSpec.BackColor == Color.Aqua)
          {
            btnSpec.BackColor = DefaultBackColor;
          }
          else
          {
            btnSpec.BackColor = Color.Aqua;
          }
          
        }
        else
        {
          btnSpec.BackColor = DefaultBackColor;
        }
      }


    }

    string GetSelectGuiGe()
    {
      var btn = mCalculateSpecs.FirstOrDefault(x => x.BackColor == Color.Aqua);
      if (btn == null)
      {
        return "";
      }
      return btn.Text;
    }

    string GetSelectPinLei()
    {
      var btn = mPinLei.FirstOrDefault(x => x.BackColor == Color.Aqua);
      if (btn == null)
      {
        throw new Exception("没有选中的品类");
      }
      return btn.Text;
    }

    string GetSelectFenLei()
    {
      var btn = mFenLei.FirstOrDefault(x => x.BackColor == Color.Aqua);
      if (btn == null)
      {
        throw new Exception("没有选中的分类");
      }
      return btn.Text;
    }

    private void InitButtonLists()
    {
      //创建品类
      foreach (var group in mLocalManualSetList.Where(y=> y.WorkshopCategory_Name == mWorkshopCategory).GroupBy(x => x.FrozenInStoreSet_Name))
      {
        var btn = CreatePinLeiButton(group.Key);
        mPinLei.Add(btn);
        flpPinLei.Controls.Add(btn);
      }

    }



    private void BtnPinLei_Click(object sender, EventArgs e)
    {
      var btn = sender as Button;
      //设置背景色
      foreach (var btnPinLei in mPinLei)
      {
        if (btnPinLei == btn)
        {
          btnPinLei.BackColor = Color.Aqua;
        }
        else
        {
          btnPinLei.BackColor = DefaultBackColor;
        }
      }
      //设置分类
      var details = mLocalManualSetList.Where(y => y.WorkshopCategory_Name == mWorkshopCategory).Where(x => x.FrozenInStoreSet_Name == btn.Text).GroupBy(x => x.CalculateCatalog_Name);

      flpFenLei.Controls.Clear();
      mFenLei.Clear();

      flpGoods.Controls.Clear();
      mGoods.Clear();


      foreach (var group in details)
      {
        if (!string.IsNullOrWhiteSpace(group.Key))
        {
          var btnFenLei = CreateFenLeiButton(group.Key);
          mFenLei.Add(btnFenLei);
          flpFenLei.Controls.Add(btnFenLei);
        }
      }

    }

    //点击分类
    private void BtnFenLei_Click(object sender, EventArgs e)
    {
      var btn = sender as Button;
      //设置背景色
      foreach (var btnFenLei in mFenLei)
      {
        if (btnFenLei == btn)
        {
          btnFenLei.BackColor = Color.Aqua;
        }
        else
        {
          btnFenLei.BackColor = DefaultBackColor;
        }
      }

      flpGoods.Controls.Clear();
      mGoods.Clear();

      //设置存货
      var goodsDetails = mLocalManualSetList.Where(x => x.FrozenInStoreSet_Name == GetSelectPinLei() && x.CalculateCatalog_Name == btn.Text && x.WorkshopCategory_Name == mWorkshopCategory).ToList();
      //创建存货
      foreach (ManualSet set in goodsDetails)
      {
        var btnGoods = CreateGoodsButton(set);
        mGoods.Add(btnGoods);
        flpGoods.Controls.Add(btnGoods);
        //Application.DoEvents();
      }
    }

    Button CreatePinLeiButton(string text)
    {
      var btn = new Button() { Text = text };
      btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      btn.Name = text;
      btn.Size = new System.Drawing.Size(80, 55);
      btn.Text = text;
      btn.UseVisualStyleBackColor = true;
      btn.Click += BtnPinLei_Click;
      return btn;
    }
    Button CreateFenLeiButton(string text)
    {
      var btn = new Button() { Text = text };
      //btn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)| System.Windows.Forms.AnchorStyles.Right)));
      btn.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
      btn.Name = text;
      btn.Size = new System.Drawing.Size(flpFenLei.Width - 6, 55);
      btn.Text = text;
      btn.UseVisualStyleBackColor = true;
      btn.Click += BtnFenLei_Click;
      return btn;
    }



    ManualSetControl CreateGoodsButton(ManualSet manualSet)
    {
      var msetControl = new ManualSetControl(manualSet, MsetControl_ManualSetCheckedChanged);
      return msetControl;
    }

    private void MsetControl_ManualSetCheckedChanged(object sender, ManualSetEventArgu e)
    {
      //if (!e.IsCheckBoxClick)
      //{
      mSelectedManualSet = e.ManualSet;
      //}
      SetDefaultBackColorAll();
      SetSelectGoodsSpec();
    }

    void SetSelectGoodsSpec()
    {
      foreach (Button control in mCalculateSpecs)
      {
        if (control.Text == mSelectedManualSet.CalculateSpec_Name)
        {
          control.BackColor = Color.Aqua;
        }
        else
        {
          control.BackColor = DefaultBackColor;
        }
      }
    }

    void SetDefaultBackColorAll()
    {
      foreach (ManualSetControl control in mGoods)
      {
        if (control.ManualSet != mSelectedManualSet)
        {
          control.BackColor = DefaultBackColor;
        }
      }
    }

    private void btnSaveAll_Click(object sender, EventArgs e)
    {
        foreach (var item in mLocalManualSetList)
        {
            if (string.IsNullOrWhiteSpace(item.PlanNumber))
            {
                item.PlanNumber = DateTime.Today.ToString("yyyyMMdd");
            }
        }
      XmlUtil.SerializerObjToFile(mLocalManualSetList, ManualSetListFileName);
      DialogResult = DialogResult.OK;
      Close();
    }

    private void btnConfirmSpec_Click(object sender, EventArgs e)
    {
      var spec = GetSelectGuiGe();
        if (!string.IsNullOrWhiteSpace(spec) && mSelectedManualSet != null)
        {
            mSelectedManualSet.CalculateSpec_Name = spec;
        }
        else
        {
            MessageBox.Show("选中计数名称和规格");
        }
     
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
      var f = new AddSpecForm();
      if (f.ShowDialog() == DialogResult.OK)
      {
        var spec = f.GoodsSpec;
        var btn = CreateGuiGeButton(spec);
        mCalculateSpecs.Add(btn);
        flpGuiGe.Controls.Add(btn);
      }
    }

    private void button_MouseDown(object sender, MouseEventArgs e)
    {
      var btn = sender as Button;
      btn.BackColor = Color.Aqua;
    }

    private void button_MouseUp(object sender, MouseEventArgs e)
    {
      var btn = sender as Button;
      btn.BackColor = SystemColors.Control; ;
    }
  }
}
