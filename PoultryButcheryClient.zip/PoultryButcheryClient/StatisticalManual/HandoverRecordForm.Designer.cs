﻿namespace StatisticalManual
{
  partial class HandoverRecordForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.选择 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.计数名称 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.计划号 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.计数记录 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.删除最后一次 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.记录数 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.袋数 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.重量 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.button2);
            this.splitContainer1.Panel1.Controls.Add(this.button1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView1);
            this.splitContainer1.Size = new System.Drawing.Size(1350, 729);
            this.splitContainer1.SplitterDistance = 51;
            this.splitContainer1.TabIndex = 0;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.Font = new System.Drawing.Font("宋体", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.button2.Location = new System.Drawing.Point(1247, 3);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(103, 45);
            this.button2.TabIndex = 1;
            this.button2.Text = "关闭";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(117, 45);
            this.button1.TabIndex = 0;
            this.button1.Text = "提交选中";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeight = 40;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.选择,
            this.计数名称,
            this.计划号,
            this.计数记录,
            this.删除最后一次,
            this.记录数,
            this.袋数,
            this.重量});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 40;
            this.dataGridView1.Size = new System.Drawing.Size(1350, 674);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.CellMouseMove += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseMove);
            this.dataGridView1.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dataGridView1_DataError);
            this.dataGridView1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseDown);
            // 
            // 选择
            // 
            this.选择.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.选择.HeaderText = "";
            this.选择.Name = "选择";
            this.选择.ReadOnly = true;
            this.选择.Width = 50;
            // 
            // 计数名称
            // 
            this.计数名称.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.计数名称.DataPropertyName = "CalculateGoods_Name";
            this.计数名称.HeaderText = "计数名称";
            this.计数名称.MinimumWidth = 120;
            this.计数名称.Name = "计数名称";
            this.计数名称.ReadOnly = true;
            this.计数名称.Width = 120;
            // 
            // 计划号
            // 
            this.计划号.DataPropertyName = "PlanNumber";
            this.计划号.HeaderText = "计划号";
            this.计划号.MinimumWidth = 120;
            this.计划号.Name = "计划号";
            this.计划号.ReadOnly = true;
            this.计划号.Width = 120;
            // 
            // 计数记录
            // 
            this.计数记录.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.计数记录.DataPropertyName = "StrRecords";
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.计数记录.DefaultCellStyle = dataGridViewCellStyle1;
            this.计数记录.HeaderText = "计数记录";
            this.计数记录.Name = "计数记录";
            this.计数记录.ReadOnly = true;
            // 
            // 删除最后一次
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.NullValue = "删除";
            this.删除最后一次.DefaultCellStyle = dataGridViewCellStyle2;
            this.删除最后一次.HeaderText = "删除最后一次";
            this.删除最后一次.Name = "删除最后一次";
            this.删除最后一次.ReadOnly = true;
            this.删除最后一次.Width = 120;
            // 
            // 记录数
            // 
            this.记录数.DataPropertyName = "StrRecordCount";
            this.记录数.HeaderText = "记录数";
            this.记录数.Name = "记录数";
            this.记录数.ReadOnly = true;
            // 
            // 袋数
            // 
            this.袋数.DataPropertyName = "StrSecondIINumber";
            this.袋数.HeaderText = "袋数";
            this.袋数.Name = "袋数";
            this.袋数.ReadOnly = true;
            // 
            // 重量
            // 
            this.重量.DataPropertyName = "StrWeight";
            this.重量.HeaderText = "重量";
            this.重量.MinimumWidth = 100;
            this.重量.Name = "重量";
            this.重量.ReadOnly = true;
            // 
            // HandoverRecordForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 729);
            this.Controls.Add(this.splitContainer1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "HandoverRecordForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "交接记录";
            this.Load += new System.EventHandler(this.HandoverRecordForm_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.DataGridView dataGridView1;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.DataGridViewCheckBoxColumn 选择;
    private System.Windows.Forms.DataGridViewTextBoxColumn 计数名称;
    private System.Windows.Forms.DataGridViewTextBoxColumn 计划号;
    private System.Windows.Forms.DataGridViewTextBoxColumn 计数记录;
    private System.Windows.Forms.DataGridViewButtonColumn 删除最后一次;
    private System.Windows.Forms.DataGridViewTextBoxColumn 记录数;
    private System.Windows.Forms.DataGridViewTextBoxColumn 袋数;
    private System.Windows.Forms.DataGridViewTextBoxColumn 重量;
  }
}