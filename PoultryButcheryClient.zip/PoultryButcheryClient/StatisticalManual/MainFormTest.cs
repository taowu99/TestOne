﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BWP.WinFormControl;

namespace StatisticalManual
{
  public partial class MainFormTest : Form
  {
    public MainFormTest()
    {
      InitializeComponent();
    }

    private void MainFormTest_Load(object sender, EventArgs e)
    {
      var input1 = new ManualInputControl(new ManualInput() {CalculateGoods_ID = 1, CalculateGoods_Name = "存货存货存货1", InputNumber = 11},Input_BtnInputClick);
      var input2= new ManualInputControl(new ManualInput() {CalculateGoods_ID = 1, CalculateGoods_Name = "存货存货存货2", InputNumber = 22},Input_BtnInputClick);
      var input3 = new ManualInputControl(new ManualInput() {CalculateGoods_ID = 1, CalculateGoods_Name = "存货存货存货3", InputNumber = 33},Input_BtnInputClick);
      input1.Width = 300;
      input1.Height = 300;
      flowLayoutPanel1.Controls.Add(input1);
      flowLayoutPanel1.Controls.Add(input2);
      flowLayoutPanel1.Controls.Add(input3);
    }

    ManualInput mSelectedManualInput;
    private void Input_BtnInputClick(object sender, ManualInputEventArgu e)
    {
      
      if (!e.IsButtonClick)
      {
        mSelectedManualInput = e.ManualInput;
      }
      else
      {
        MessageBox.Show("" + e.InputNumber);
      }

      if (mSelectedManualInput == null)
      {
        MessageBox.Show("null");
      }
      else
      {
        MessageBox.Show("not null");
      }
    }

    private void button18_Click(object sender, EventArgs e)
    {
      foreach (Control control in flowLayoutPanel1.Controls)
      {
        control.BackColor = DefaultBackColor;
      }
    }
  }
}
