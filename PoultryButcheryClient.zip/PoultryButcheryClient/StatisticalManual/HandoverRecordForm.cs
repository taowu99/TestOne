﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BWP.WinFormControl;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using Forks.Utils;
using PoultryButcheryClient;
using PoultryButcheryClient.BO.BO.Bill;
using PoultryButcheryClient.BO.Utils;
using PoultryButcheryClient.BO.Utils.BillSync;

namespace StatisticalManual
{
  public partial class HandoverRecordForm : Form
  {
    private string mCalculateGoodsName;
    public HandoverRecordForm(string calculateGoodsName)
    {
      InitializeComponent();
      dataGridView1.AutoGenerateColumns = false;
      mCalculateGoodsName = calculateGoodsName;


    }

    private BindingList<HandoverRecordForUi> mRecordList;

    //private BindingList blist;
    private void HandoverRecordForm_Load(object sender, EventArgs e)
    {

        reloadFronService();

        //默认全部选中，用户总是选择一个就提交  
        foreach (DataGridViewRow item in dataGridView1.Rows)
        {
            var checkCell = (DataGridViewCheckBoxCell)item.Cells["选择"];
            checkCell.Value = true;
        }



    }

    private void reloadFronService()
    {
      var list  = HandoverRecordRpc.GetList(mCalculateGoodsName);
      mRecordList = new BindingList<HandoverRecordForUi>(list);
      DataGridViewBind();
    }

    void DataGridViewBind()
    {
      dataGridView1.DataSource = mRecordList;
      dataGridView1.ResumeLayout();
      dataGridView1.Refresh();
      AddCheckBoxToDataGridView.dgv = dataGridView1;
      AddCheckBoxToDataGridView.AddFullSelect();

    }

    private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
    {
      if (e.ColumnIndex < 0 || e.RowIndex < 0)
      {
        return;
      }
      if (e.ColumnIndex == 0)
      {
        var checkCell = (DataGridViewCheckBoxCell)this.dataGridView1.Rows[e.RowIndex].Cells["选择"];
        Boolean flag = Convert.ToBoolean(checkCell.Value);
        if (flag == true)
        {
          checkCell.Value = false;
        }
        else
        {
          checkCell.Value = true;
        }
      }
        //选中 列
        if (e.ColumnIndex == 3)
        {
            var recordStr = dataGridView1.Rows[e.RowIndex].Cells["计数记录"].Value;
            if (recordStr != null)
                MessageBox.Show(recordStr.ToString());
        }
      //删除
      if (e.ColumnIndex == 4)
      {
        var value1 = dataGridView1.Rows[e.RowIndex].Cells["计数名称"].Value;
        if (value1 == null)
        {
          return;
        }
        var value2 = dataGridView1.Rows[e.RowIndex].Cells["计划号"].Value;

        var planNumber = "";
        if (value2 != null)
        {
            planNumber = value2.ToString();
        }
        var goodsName = value1.ToString();
        HandoverRecordRpc.DeleteLastRecord(goodsName, planNumber);
        var detail = mRecordList.FirstOrDefault(x => (x.CalculateGoods_Name == goodsName && x.PlanNumber == planNumber));
        var details = detail.Details;
        if (details.Count > 0)
        {
          details.RemoveAt(details.Count - 1);
        }
        if (details.Count == 0)
        {
          mRecordList.Remove(detail);
        }
        DataGridViewBind();
      }
    }

    private void dataGridView1_DataError(object sender, DataGridViewDataErrorEventArgs e)
    {
      
    }

    private void button1_Click(object sender, EventArgs e)
    {
      var list = new List<HandoverRecordForUi>();
      for (int i = 0; i < dataGridView1.Rows.Count; i++)
      {
        DataGridViewCheckBoxCell checkCell = (DataGridViewCheckBoxCell)dataGridView1.Rows[i].Cells["选择"];
        Boolean selected = Convert.ToBoolean(checkCell.Value);
        if (selected)
        {
          list.Add(mRecordList[i]);
        }
      }
        if (list.Count() == 0)
        {
            MessageBox.Show("请选中提交");
            return;
            
        }

      CreateOutPut(list);
    }

    private void CreateOutPut(List<HandoverRecordForUi> list)
    {
      var c = ButcherAppContext.Context.UserConfig;
        var dmo = new RpcObject("/MainSystem/PoultryButcheryClientService/RpcBO/OutPut");
        dmo.Set("AccountingUnit_ID", c.AccountingUnit_ID);
        dmo.Set("Department_ID", c.Department_ID);
        dmo.Set("CreateUser_Name", c.UserName);

        var allHandoverRecord = new List<long>();//存放所有的中间服务器 记录ID


          foreach (HandoverRecordForUi record in list)
          {
              var detail = new RpcObject("/MainSystem/PoultryButcheryClientService/RpcBO/Output_Detail");
              detail.Set("CalculateGoods_ID", record.CalculateGoods_ID);
              
              detail.Set("CalculateGoods_Name", record.CalculateGoods_Name);
              detail.Set("Goods_ID", record.Goods_ID);
              detail.Set("Number", Convert.ToDecimal(record.StrWeight));
              detail.Set("SecondNumber", Convert.ToDecimal(record.StrInputNumber));
              detail.Set("SecondNumber2", Convert.ToDecimal(record.StrSecondIINumber));
              detail.Set("CalculateSpec_Name", record.CalculateSpec_Name);
              detail.Set("RecordCount", Convert.ToInt32(record.StrRecordCount));
              detail.Set("PlanNumber", record.PlanNumber);
              dmo.Get<ManyList>("Details").Add(detail);
              var ids = record.Details.Select(x => x.HandoverRecordID);
              allHandoverRecord.AddRange(ids);
          }
          var allIDsStr = string.Join("|", allHandoverRecord);
          RpcFacade.Call<long>("/MainSystem/PoultryButcheryClientService/Rpcs/BillRpc/OutPutRpc/CreateOutPut", dmo, allIDsStr);

      
     
      MessageBox.Show("创建成功");
      reloadFronService();
    }

    private void dataGridView1_CellMouseMove(object sender, DataGridViewCellMouseEventArgs e)
    {

    }

    private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
    {

    }

    private void button2_Click(object sender, EventArgs e)
    {
        Close();
    }


  }
}
