﻿namespace PoultryButcheryClient.BO.BO
{
  public abstract class SyncBase
  {
    public long ID { get; set; }

    public int Index { get; set; }

    public bool DeleteState { get; set; }
  }
}
