﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.BaseInfo.ClientGoodsSet_
{
    public class ClientGoodsSet_Detail
    {


        public long ClientGoodsSet_ID { get; set; }
        public long? GoodsProperty_ID { get; set; }//存货属性
        public string GoodsProperty_Name { get; set; }//存货属性
        public long Goods_ID { get; set; }


        public string Goods_Name { get; set; }


        public string Goods_Code { get; set; }


        public string Goods_Spec { get; set; }

        public string Goods_Spell { get; set; }

        public decimal? Goods_MainUnitRatio { get; set; }
        public decimal? Goods_SecondUnitII_MainUnitRatio { get; set; }
        
        public DateTime? CompletedDate { get; set; }



        public decimal? Goods_StandardSecondNumber { get; set; }//一车 默认的箱数




        private bool _isSelected = false;
        public bool isSelectd { get { return _isSelected; } set { _isSelected = value; } }
    }
}
