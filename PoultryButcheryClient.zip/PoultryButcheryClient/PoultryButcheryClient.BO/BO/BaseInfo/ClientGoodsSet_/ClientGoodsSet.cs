﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.BaseInfo.ClientGoodsSet_
{
    public class ClientGoodsSet
    {
        public string Name { get; set; }
  
        private List<ClientGoodsSet_Detail> mDetails = new List<ClientGoodsSet_Detail>();
        public List<ClientGoodsSet_Detail> Details { get { return mDetails; } set { mDetails = value; } }
    }
}
