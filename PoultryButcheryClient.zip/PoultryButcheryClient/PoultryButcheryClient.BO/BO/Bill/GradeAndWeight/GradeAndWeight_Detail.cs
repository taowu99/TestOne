﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO.Bill
{
  public class GradeAndWeight_Detail
  {
    public long ID { get; set; }

    public bool ReadWeight { get; set; }

    public long? OrderDetail_ID { get; set; }

    public int Index { get; set; }

    public DateTime Date { get; set; }

    public short Technics { get; set; }

    public string Technics_Name { get; set; }

    public long Livestock_ID { get; set; }

    public string Livestock_Name { get; set; }

    public decimal? Weight { get; set; }

    public DateTime Time { get; set; }

    public DateTime TempTime { get { return Time; } }
  }
}
