﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.Bill.FrozenInStoreSetBillSync_
{
  [Serializable]
  public class FrozenInStoreSetBill_Detail
  {
    public long FrozenInStoreSetBill_ID { get; set; }
    public long CalculateGoods_ID { get; set; }
    public string CalculateGoods_Name { get; set; }
    public string CalculateGoods_Code { get; set; }
    public string CalculateGoods_MainUnit { get; set; }
    public string CalculateGoods_SecondUnit { get; set; }
    public decimal? MainUnitRatio { get; set; }
    public decimal? SecondUnitRatio { get; set; }
    public int? UnitConvertDirection { get; set; }
    public string SecondUnitII { get; set; }
    public decimal? SecondUnitII_MainUnitRatio { get; set; }
    public decimal? SecondUnitII_SecondUnitRatio { get; set; }
    public long? CalculateCatalog_ID { get; set; }
    public string CalculateCatalog_Name { get; set; }
    public int? DefaultNumber1 { get; set; }
    public long? Goods_ID { get; set; }
  }
}
