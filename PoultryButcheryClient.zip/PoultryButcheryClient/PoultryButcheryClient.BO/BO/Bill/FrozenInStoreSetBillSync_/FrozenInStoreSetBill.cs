﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.Bill.FrozenInStoreSetBillSync_
{
  [Serializable]
  public class FrozenInStoreSetBill
  {
    public string Name { get; set; }
    public string WorkshopCategory_Name{ get; set; }

    private List<FrozenInStoreSetBill_Detail> mDetails=new List<FrozenInStoreSetBill_Detail>();
    public List<FrozenInStoreSetBill_Detail> Details { get { return mDetails; } set { mDetails = value; }}
  }
}
