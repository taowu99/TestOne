﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.Bill
{
 
    [Serializable]
    public class WorkShopRecord
    {
        public long ID { get; set; }

        //叉车板条码
        public string ChaCarBoardCode { get; set; }

        public string BarCode { get; set; }//箱子上的条码
        public string Goods_Spell { get; set; }
        public decimal? Number { get; set; }
        public decimal? SecondNumber { get; set; }
        public decimal? SecondNumber2 { get; set; }
        public string Goods_Code{ get; set; }
        public string Goods_Spec { get; set; }

        public string Goods_Name { get; set; }

        public long Goods_ID { get; set; }


        public string PlanNumber { get; set; }


        private DateTime _date = DateTime.Now;
        public DateTime CreateTime { get { return _date; } set { _date = value; } }

        public string BiaoShi { get; set; }

        public int No { get; set; }//序号 -----当前一拍下的 第几个

    }
}
