﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO
{
  public class HouseAndSanctionEdit
  {
    public long ID { get; set; }

    public int? Number { get; set; }

    public long? HogGrade_ID { get; set; }

    #region 获取的时候不赋值，只负责接收
    public string HogGrade_Name { get; set; }

    public long? Inspector_ID { get; set; }

    public string Inspector_Name { get; set; }
    #endregion


    private List<WeightBill_HouseDetail> _houseDetails = new List<WeightBill_HouseDetail>();
    public List<WeightBill_HouseDetail> HouseDetails { get { return _houseDetails; } set { _houseDetails = value; } }

    private List<WeightBill_SanctionDetail> _sanctionDetails = new List<WeightBill_SanctionDetail>();
    public List<WeightBill_SanctionDetail> SanctionDetails { get { return _sanctionDetails; } set { _sanctionDetails = value; } }
  }
}
