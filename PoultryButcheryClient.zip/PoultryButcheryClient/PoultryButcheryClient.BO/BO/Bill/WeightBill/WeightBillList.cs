﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO
{
  public class WeightBillList
  {
    public long ID { get; set; }

    public long? B3ID { get; set; }

    public string Car_Name { get; set; }

    public string Supplier_Name { get; set; }

    public string Employee_Name { get; set; }

    public string PurchaseType_Name { get; set; }

    public int? Number { get; set; }

    public decimal? Weight { get; set; }

    public string HouseNames { get; set; }

    public decimal? SanctionMoney { get; set; }

    public string Remark { get; set; }

    public bool FinishWeight { get; set; }
  }
}
