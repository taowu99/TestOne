﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO
{
  public class PrintWeightBill
  {
    public long? ID { get; set; }

    public string Supplier_Name { get; set; }

    public DateTime WeighTime { get; set; }

    public string Creator { get; set; }

    public string Employee_Name { get; set; }

    public string Inspector_Name { get; set; }

    public string HogGrade_Name { get; set; }

    public decimal? Weight { get; set; }

    public int? Number { get; set; }

    public string TotalDiscont { get { return string.Format("{0:#0.######}", Details.Sum(x => x.Money ?? 0)); } }

    private List<PWeightBill_SanctionDetail> _details = new List<PWeightBill_SanctionDetail>();
    public List<PWeightBill_SanctionDetail> Details { get { return _details; } set { _details = value; } }
  }

  public class PWeightBill_SanctionDetail
  {
    public string AbnormalItem_Name { get; set; }

    public int? Number { get; set; }

    public decimal? Money { get; set; }
  }
}
