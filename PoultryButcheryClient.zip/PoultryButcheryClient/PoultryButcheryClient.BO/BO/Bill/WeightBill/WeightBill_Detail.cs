﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PoultryButcheryClient.BO.BO;

namespace BO.BO
{
  [Serializable]
  public class WeightBill_Detail : SyncBase
  {
    public long WeightBill_ID { get; set; }

    public int? Number { get; set; }

    public decimal? PiWeight { get; set; }

    public decimal? MaoWeight { get; set; }

    public decimal? Weight { get; set; }
  }
}
