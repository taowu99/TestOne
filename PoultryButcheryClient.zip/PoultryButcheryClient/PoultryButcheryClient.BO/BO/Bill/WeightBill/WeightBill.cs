﻿using Forks.EnterpriseServices.DomainObjects2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TSingSoft.WebPluginFramework;

namespace BO.BO
{
  [Serializable]
  public class WeightBill
  {
    public int RowVersion { get; set; }
    public long ID { get; set; }

    public long? B3ID { get; set; }

    public string Creator { get; set; }

    public long? AccountingUnit_ID { get; set; }

    public long? Department_ID { get; set; }

    public long? Employee_ID { get; set; }

    public string Employee_Name { get; set; }

    public DateTime? WeighTime { get; set; }

    public long? Supplier_ID { get; set; }

    public string Supplier_Name { get; set; }

    public long? Zone_ID { get; set; }

    public string Zone_Name { get; set; }

    public short? PurchaseType_ID { get; set; }

    public string PurchaseType_Name { get; set; }

    public long? Car_ID { get; set; }

    public string Car_Name { get; set; }

    public long? LiveVarieties_ID { get; set; }

    public string LiveVarieties_Name { get; set; }

    public long? HogGrade_ID { get; set; }

    public string HogGrade_Name { get; set; }

    public decimal? ShackWeight { get; set; }

    public decimal? ShackPrice { get; set; }

    public decimal? ShackMoney
    {
      get
      {
        var v = ShackPrice * ShackWeight;
        if (v.HasValue)
          return decimal.Round(v.Value, 2);
        return null;
      }
    }

    public decimal? JingJianFee { get; set; }

    public decimal? DiscontMoney { get; set; }

    public string AnimalTestNumber { get; set; }

    public DateTime? AnimalTestDate { get; set; }

    public string AnimalTestMan { get; set; }

    public long? Inspector_ID { get; set; }

    public string Inspector_Name { get; set; }

    public string Remark { get; set; }

    private List<WeightBill_Detail> _details = new List<WeightBill_Detail>();
    public List<WeightBill_Detail> Details { get { return _details; } set { _details = value; } }

    private List<WeightBill_FarmerDetail> _farmerDetails = new List<WeightBill_FarmerDetail>();
    public List<WeightBill_FarmerDetail> FarmerDetails { get { return _farmerDetails; } set { _farmerDetails = value; } }
  }
}
