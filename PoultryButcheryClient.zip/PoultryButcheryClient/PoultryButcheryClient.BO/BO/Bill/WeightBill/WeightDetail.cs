﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO
{
  [Serializable]
  public class WeightDetail
  {
    public long ID { get; set; }
    public long WeightBill_Detail_ID { get; set; }

    public string Type { get; set; }

    public decimal Weight { get; set; }

    public DateTime? Time { get; set; }

    public bool Delete { get; set; }
  }
}
