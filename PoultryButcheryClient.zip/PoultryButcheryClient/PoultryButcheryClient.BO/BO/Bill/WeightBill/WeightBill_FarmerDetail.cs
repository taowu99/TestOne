﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PoultryButcheryClient.BO.BO;

namespace BO.BO
{
  [Serializable]
  public class WeightBill_FarmerDetail : SyncBase
  {
    public long WeightBill_ID { get; set; }

    public long? Farmer_ID { get; set; }

    public string Farmer_Name { get; set; }

    public int? Number { get; set; }

    public decimal? Weight { get; set; }
  }
}
