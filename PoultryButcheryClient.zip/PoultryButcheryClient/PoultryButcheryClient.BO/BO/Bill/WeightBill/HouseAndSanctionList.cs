﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO
{
  public class HouseAndSanctionList
  {
    public long ID { get; set; }

    public long? B3ID { get; set; }

    public string Employee_Name { get; set; }

    public string Supplier_Name { get; set; }

    public int? Number { get; set; }

    public string HouseNames { get; set; }

    public bool AlreadyHouse { get { return !string.IsNullOrEmpty(HouseNames); } }
  }
}
