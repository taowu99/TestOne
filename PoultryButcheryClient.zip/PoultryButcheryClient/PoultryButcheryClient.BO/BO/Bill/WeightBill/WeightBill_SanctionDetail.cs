﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PoultryButcheryClient.BO.BO;

namespace BO.BO
{
  [Serializable]
  public class WeightBill_SanctionDetail : SyncBase
  {
    public long WeightBill_ID { get; set; }

    /// <summary>
    /// 异常奖罚配置
    /// </summary>
    public long? Sanction_ID { get; set; }

    /// <summary>
    /// 异常项目ID
    /// </summary>
    public long? AbnormalItem_ID { get; set; }

    /// <summary>
    /// 异常项目名称
    /// </summary>
    public string AbnormalItem_Name { get; set; }

    public int? Number { get; set; }
  }
}
