﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.Bill
{
  public class HandoverRecordForUi
  {
    public HandoverRecordForUi()
    {
      Details=new List<HandoverRecordDetailForUi>();
    }
    public string PlanNumber { get; set; }//计划号
    public string CalculateSpec_Name { get; set; }

    public string CalculateGoods_Name { get; set; }
      public long? CalculateGoods_ID { get; set; }
    public long Goods_ID { get; set; }


    //显示记录
    public string StrRecords { get { return string.Join("+", Details.Select(x=>(x.InputNumber??0).ToString("0.##"))); }}

    //记录的次数 也就是车数
    public string StrRecordCount {
      get { return Details.Count + ""; }
    }
    //重量
    public string StrWeight
    {
      get
      {
        var w = Details.Sum(x => x.Weight)??0;
        return w.ToString("0.##");
      }
    }

    //袋数
    public string StrSecondIINumber
    {
      get
      {
        var w = Details.Sum(x => x.SecondIINumber) ??0;
        return w.ToString("0.##");
      }
    }

    //盘数
    public string StrInputNumber
    {
      get
      {
        var w = Details.Sum(x => x.InputNumber) ??0;
        return w.ToString("0.##");
      }
    }

    public List<HandoverRecordDetailForUi> Details { get; set; }

  }

  public class HandoverRecordDetailForUi
  {

   
      public long HandoverRecordID { get; set; }//中间服务器记录ID
    public decimal? InputNumber { get; set; }
    public decimal? MainUnitRatio { get; set; }
    public decimal? SecondIINumber { get; set; }
    public decimal? Weight { get; set; }
  }
}
