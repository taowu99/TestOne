﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO.Bill
{
  public class NeedOrderEntity
  {
    public long? B3ID { get; set; }

    public long WeightBill_ID { get; set; }

    public bool Show { get; set; }

    public string Supplier_Name { get; set; }

    public string HouseNames { get; set; }

    public int Number { get; set; }

    public int AlreadyNumber { get; set; }

    public int LastNumber { get { return Number - AlreadyNumber; } }

    public DateTime WeighTime { get; set; }
  }
}
