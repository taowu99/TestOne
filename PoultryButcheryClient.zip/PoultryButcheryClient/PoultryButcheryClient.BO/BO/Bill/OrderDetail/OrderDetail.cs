﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO.Bill
{
  public class OrderDetail
  {
    public long ID { get; set; }

    public string Creator { get; set; }

    public long? AccountingUnit_ID { get; set; }

    public DateTime? Date { get; set; }

    public long WeightBill_ID { get; set; }

    public long? B3WeighBill_ID { get; set; }

    public int Order { get; set; }

    public int PlanNumber { get; set; }

    public string LiveColonyHouse_Name { get; set; }

    public bool IsHurryButcher { get; set; }

    public bool SecondarySplit { get; set; }
  }
}
