﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO.Bill
{
  public class ConfirmOrder
  {
    public long ID { get; set; }

    public int Order { get; set; }

    public long? B3WeighBill_ID { get; set; }

    public string LiveColonyHouse_Name { get; set; }

    public int Number { get; set; }

    public bool Confirmed { get; set; }
  }
}
