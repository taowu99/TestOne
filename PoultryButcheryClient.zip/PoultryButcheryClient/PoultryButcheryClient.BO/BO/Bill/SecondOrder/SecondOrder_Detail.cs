﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO.Bill
{
  public class SecondOrder_Detail
  {
    public long ID { get; set; }

    public long SecondOrder_ID { get; set; }

    public int Number { get; set; }

    public DateTime Time { get; set; }
  }
}
