﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO.BO.Bill
{
  public class SecondOrder
  {
    public long ID { get; set; }
    public long OrderDetail_ID { get; set; }

    public int? Order { get; set; }

    public int? PlanNumber { get; set; }

    public int HotFadeNumber { get; set; }

    public bool IsOk { get; set; }

    public bool Finish { get; set; }
  }
}
