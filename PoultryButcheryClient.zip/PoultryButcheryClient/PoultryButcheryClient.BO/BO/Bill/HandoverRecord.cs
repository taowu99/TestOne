﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.BO.Bill
{
  public class HandoverRecord
  {
      public long ID { get; set; }//中间服务器ID

      public string PlanNumber { get; set; }//计划号
      public long? CalculateGoods_ID { get; set; }

    public string CalculateGoods_Name { get; set; }

    public string CalculateSpec_Name { get; set; }

    public decimal? InputNumber { get; set; }
   
    public decimal? SecondIINumber { get; set; }

    public decimal? MainUnitRatio { get; set; }

    public decimal? SecondUnitII_MainUnitRatio { get; set; }

    public bool? IsSecondⅡ { get; set; }

    public decimal? Weight { get; set; }
    public long Goods_ID { get; set; }

    public string BiaoShi { get; set; }//标识 记录哪台电脑

  }
}
