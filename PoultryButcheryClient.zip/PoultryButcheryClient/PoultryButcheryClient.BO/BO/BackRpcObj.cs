﻿using System.Collections.Generic;

namespace PoultryButcheryClient.BO.BO
{
  public class BackRpcObj
  {
    public long ID { get; set; }

    public string Flag { get; set; }

    private List<BackRpcObj> _detailBack = new List<BackRpcObj>();

    public List<BackRpcObj> DetailBack { get { return _detailBack; } set { _detailBack = value; } }
  }
}
