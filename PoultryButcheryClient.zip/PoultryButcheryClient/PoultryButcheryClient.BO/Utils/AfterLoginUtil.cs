﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

namespace PoultryButcheryClient.BO.Utils
{
  public enum InputType
  {
    Manual=1,
    Weight=2
  }


  public interface IAfterLoginForm 
  {
      Form Generate();
  }
  public interface IMainInterface
  {
    InputType InputType { get; }

    Form Generate();
  }

  public static class AfterLoginUtil
  {

  //  static List<Tuple<string, string>> roleToAssemblies = new List<Tuple<string, string>>(){new Tuple<string,string>("排宰员",@"C:\BwpB3Project\src\B3PoultryButcheryClient\ButcherOrder\bin\Debug\ButcherOrder"),
  //new Tuple<string,string>("过磅员",@"C:\BwpB3Project\src\B3PoultryButcheryClient\ButcherWeight\bin\Debug\ButcherWeight"),
  // new Tuple<string,string>("验质员",@"C:\BwpB3Project\src\B3PoultryButcheryClient\QualityAndOrder\bin\Debug\QualityAndOrder"),new Tuple<string,string>("定级员",@"C:\BwpB3Project\src\B3PoultryButcheryClient\WeighAndGrading\bin\Debug\WeighAndGrading"),new Tuple<string,string>("窒晕员",@"C:\BwpB3Project\src\B3PoultryButcheryClient\OrderConfirm\bin\Debug\OrderConfirm")};

    static List<Tuple<InputType, string>> inputTypeToAssemblies = new List<Tuple<InputType, string>>(){new Tuple<InputType,string>(InputType.Manual,@"StatisticalManual"),
    new Tuple<InputType,string>(InputType.Weight,@"StatisticalManual")};


    public static Form CreateAfterLoginForm(string dllName)
    {
        dllName += ".dll";
        var filePath = Path.Combine(Application.StartupPath, dllName);
        if (!File.Exists(filePath)) 
        { 
            throw new Exception("相关模块不存在,请配置字段" + filePath);
        }
        var formType = typeof(IAfterLoginForm);

        foreach(var type in Assembly.LoadFile(filePath).GetTypes()) 
        {
            if (formType.IsAssignableFrom(type)) 
            {
                var instance = (IAfterLoginForm)Activator.CreateInstance(type);
                return instance.Generate();
            
            }
        
        }


        return null;
    }


    public static Form CreateStatisticalManualForm(InputType inputType, string workshopCategoryName)
    {
      var first = inputTypeToAssemblies.FirstOrDefault(x => x.Item1 == inputType);
      if (first == null)
        throw new Exception("未注册的输入类型："+inputType);
//#if debug
      //var filePath = string.Format("{0}.dll", first.Item2);
//#endif
//#if !debug
      var filePath = Path.Combine(Application.StartupPath, string.Format("{0}.dll", first.Item2));
//#endif
      if (!File.Exists(filePath))
        throw new Exception("相关模块不存在");
      var formType = typeof(IMainInterface);
      foreach (var type in Assembly.LoadFile(filePath).GetTypes())
      {
        if (formType.IsAssignableFrom(type))
        {
          var instance = (IMainInterface)Activator.CreateInstance(type,new object[]{ workshopCategoryName });
          if (inputType == instance.InputType)
            return instance.Generate();
        }
      }
      return null;
    }
  }
}
