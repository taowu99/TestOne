﻿using System.Collections.Generic;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using PoultryButcheryClient.BO.BO.Bill.FrozenInStoreSetBillSync_;

namespace PoultryButcheryClient.BO.Utils.BillSync
{
  public class FrozenInStoreSetBillSync
  {
    public static List<FrozenInStoreSetBill> GetFrozenInStoreSetBillList(string workshopCategoryName)
    {
      var list=new List<FrozenInStoreSetBill>();
      var objList = RpcFacade.Call<List<RpcObject>>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetFrozenInStoreSetBillList", workshopCategoryName);

      foreach (RpcObject rpcObject in objList)
      {
        var bill=new FrozenInStoreSetBill();
        SetFrozenInStoreSetBill(bill, rpcObject);
        foreach (RpcObject detailRpcObject in rpcObject.Get<ManyList>("Details"))
        {
          var detail=new FrozenInStoreSetBill_Detail();
          SetFrozenInStoreSetBill_Detail(detail, detailRpcObject);
          bill.Details.Add(detail);
        }
        list.Add(bill);
      }

      return list;

    }
    private static void SetFrozenInStoreSetBill(FrozenInStoreSetBill bill, RpcObject rpcObject)
    {
      bill.Name = rpcObject.Get<string>("Name");
      bill.WorkshopCategory_Name = rpcObject.Get<string>("WorkshopCategory_Name");
    }

    private static void SetFrozenInStoreSetBill_Detail(FrozenInStoreSetBill_Detail detail, RpcObject detailRpcObject)
    {
      detail.FrozenInStoreSetBill_ID = detailRpcObject.Get<long>("FrozenInStoreSetBill_ID");
      detail.CalculateGoods_ID = detailRpcObject.Get<long>("CalculateGoods_ID");
      detail.CalculateGoods_Name = detailRpcObject.Get<string>("CalculateGoods_Name");
      detail.CalculateGoods_Code = detailRpcObject.Get<string>("CalculateGoods_Code");
      detail.CalculateGoods_MainUnit = detailRpcObject.Get<string>("CalculateGoods_MainUnit");
      detail.CalculateGoods_SecondUnit = detailRpcObject.Get<string>("CalculateGoods_SecondUnit");
      detail.MainUnitRatio = detailRpcObject.Get<decimal?>("MainUnitRatio");
      detail.SecondUnitRatio = detailRpcObject.Get<decimal?>("SecondUnitRatio");
      var ucd = detailRpcObject.Get<NamedValue>("UnitConvertDirection");
      if (ucd != null)
      {
        detail.UnitConvertDirection = ucd.Value;
      }
      detail.SecondUnitII = detailRpcObject.Get<string>("SecondUnitII") ;
      detail.SecondUnitII_MainUnitRatio = detailRpcObject.Get<decimal?>("SecondUnitII_MainUnitRatio") ;
      detail.SecondUnitII_SecondUnitRatio = detailRpcObject.Get<decimal?>("SecondUnitII_SecondUnitRatio") ;
      detail.CalculateCatalog_ID = detailRpcObject.Get<long?>("CalculateCatalog_ID") ;
      detail.CalculateCatalog_Name = detailRpcObject.Get<string>("CalculateCatalog_Name");
      detail.DefaultNumber1 = detailRpcObject.Get<int?>("DefaultNumber1");
      detail.Goods_ID = detailRpcObject.Get<long?>("Goods_ID");
    }
 
  }
}
