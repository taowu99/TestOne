﻿using BO.BO;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using PoultryButcheryClient.BO;
using PoultryButcheryClient.BO.Utils;

namespace BO.Utils.BillRpc
{
  public static class WeightBillRpc
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();
    public static List<WeightBillList> GetWeightBillList(long? carID, long? supplierID)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/GetWeightBillList";
      var obj = RpcFacade.Call<string>(method, DateTime.Today, carID, supplierID);
      return serializer.Deserialize<List<WeightBillList>>(obj);
    }

    public static WeightBill Load(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/Load";
      var obj = RpcFacade.Call<string>(method, id);
      obj = obj.ESerializeDateTime();
      return serializer.Deserialize<WeightBill>(obj);
    }

    public static bool UpdateOrInsert(WeightBill bo, List<WeightDetail> weightRecord)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/UpdateOrInsert";
      if (bo.ID == 0)
      {
        bo.Creator = ButcherAppContext.Context.UserConfig.UserName;
        bo.AccountingUnit_ID = ButcherAppContext.Context.UserConfig.AccountingUnit_ID;
        bo.Department_ID = ButcherAppContext.Context.UserConfig.Department_ID;
      }

      var s = serializer.Serialize(weightRecord);
      var json = RpcFacade.Call<string>(method, serializer.Serialize(bo), s);
      var result = serializer.Deserialize<BackRpcObj>(json);
      bo.ID = result.ID;
      bo.RowVersion += 1;
      foreach (var d in result.DetailBack)
      {
        switch (d.Flag)
        {
          case "Details":
            foreach (var rd in d.DetailBack)
            {
              var idx = Convert.ToInt32(rd.Flag);
              var first = bo.Details.First(x => !x.DeleteState && x.Index == idx);
              first.ID = rd.ID;
              first.WeightBill_ID = bo.ID;
            }
            break;
          case "FarmerDetails":
            foreach (var rd in d.DetailBack)
            {
              var idx = Convert.ToInt32(rd.Flag);
              var first = bo.FarmerDetails.First(x => !x.DeleteState && x.Index == idx);
              first.ID = rd.ID;
              first.WeightBill_ID = bo.ID;
            }
            break;
        }
      }

      return true;
    }

    public static List<WeightDetail> GetWeightRecord(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/GetWeightRecord";
      var obj = RpcFacade.Call<string>(method, id);
      obj = obj.ESerializeDateTime();
      return serializer.Deserialize<List<WeightDetail>>(obj);
    }

    public static bool Delete(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/DeleteBill";
      return RpcFacade.Call<bool>(method, id);
    }

    public static List<CTuple<long, long>> SyncBillB3Ids(List<long?> ids)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/SyncBillB3Ids";
      var json = RpcFacade.Call<string>(method, ids.ToArray());
      return serializer.Deserialize<List<CTuple<long, long>>>(json);
    }

    public static List<CTuple<long, long?, decimal?>> SyncBillB3IdsAndSanctionMoney()
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/SyncBillB3IdsAndSanctionMoney";
      var json = RpcFacade.Call<string>(method, DateTime.Today);
      return serializer.Deserialize<List<CTuple<long, long?, decimal?>>>(json);
    }

    public static PrintWeightBill GetPrintWeightBill(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/WeightBillRpc/GetPrintWeightBill";
      var obj = RpcFacade.Call<string>(method, id);
      obj = obj.ESerializeDateTime();
      return serializer.Deserialize<PrintWeightBill>(obj);
    }
  }
}
