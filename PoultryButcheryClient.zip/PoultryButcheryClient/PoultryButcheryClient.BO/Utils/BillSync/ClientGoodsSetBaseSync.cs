﻿using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using PoultryButcheryClient.BO.BO.BaseInfo.ClientGoodsSet_;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.Utils.BillSync
{
    public class ClientGoodsSetBaseSync
    {

        public static List<ClientGoodsSet> GetClientGoodsSetList()
        {
            var list = new List<ClientGoodsSet>();
            var objList = RpcFacade.Call<List<RpcObject>>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetClientGoodsSetList");

            foreach (RpcObject rpcObject in objList)
            {
                var bill = new ClientGoodsSet();
                SetClientGoodsSet(bill, rpcObject);
                foreach (RpcObject detailRpcObject in rpcObject.Get<ManyList>("Details"))
                {
                    var detail = new ClientGoodsSet_Detail();
                    SetClientGoodsSet_Detail(detail, detailRpcObject);
                    bill.Details.Add(detail);
                }
                list.Add(bill);
            }

            return list;

        }
        private static void SetClientGoodsSet(ClientGoodsSet bill, RpcObject rpcObject)
        {
            bill.Name = rpcObject.Get<string>("Name");

        }

        private static void SetClientGoodsSet_Detail(ClientGoodsSet_Detail detail, RpcObject detailRpcObject)
        {
            detail.ClientGoodsSet_ID = detailRpcObject.Get<long>("ClientGoodsSet_ID");
            detail.Goods_Spec = detailRpcObject.Get<string>("Goods_Spec");
            detail.Goods_Spell = detailRpcObject.Get<string>("Goods_Spell");
            detail.Goods_Code = detailRpcObject.Get<string>("Goods_Code");  
            detail.Goods_Name = detailRpcObject.Get<string>("Goods_Name");
            detail.Goods_MainUnitRatio = detailRpcObject.Get<decimal?>("Goods_MainUnitRatio");
            detail.GoodsProperty_ID = detailRpcObject.Get<long?>("GoodsProperty_ID");
            detail.GoodsProperty_Name = detailRpcObject.Get<string>("GoodsProperty_Name");
            detail.Goods_ID = detailRpcObject.Get<long>("Goods_ID");
            detail.CompletedDate = detailRpcObject.Get<DateTime?>("CompletedDate");
            detail.Goods_StandardSecondNumber = detailRpcObject.Get<decimal?>("Goods_StandardSecondNumber");
            detail.Goods_SecondUnitII_MainUnitRatio = detailRpcObject.Get<decimal?>("Goods_SecondUnitII_MainUnitRatio");
            
        }
    }
}
