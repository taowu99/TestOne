﻿using BO.BO;
using Forks.JsonRpc.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using PoultryButcheryClient.BO.Utils;

namespace BO.Utils.BillRpc
{
  public static class HouseAndSanctionRpc
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();
    public static List<HouseAndSanctionList> GetHouseAndSanctionList(DateTime date)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/HouseAndSanctionRpc/GetHouseAndSanctionList";
      var json = RpcFacade.Call<string>(method, date);
      return serializer.Deserialize<List<HouseAndSanctionList>>(json);
    }

    public static void UpdateInsertHouseAndSanction(HouseAndSanctionEdit bo)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/HouseAndSanctionRpc/UpdateInsertHouseAndSanction";
      bo.Inspector_ID = ButcherAppContext.Context.UserConfig.Employee_ID;
      bo.Inspector_Name = ButcherAppContext.Context.UserConfig.Employee_Name;
      RpcFacade.Call<int>(method, serializer.Serialize(bo));
    }

    public static int GetDetailTotalNumber(DateTime date)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/HouseAndSanctionRpc/GetDetailTotalNumber";
      return RpcFacade.Call<int>(method, date);
    }

    public static HouseAndSanctionEdit GetHouseAndSanctionDetail(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/HouseAndSanctionRpc/GetHouseAndSanctionDetail";
      var obj = RpcFacade.Call<string>(method, id);
      return serializer.Deserialize<HouseAndSanctionEdit>(obj);
    }
  }
}
