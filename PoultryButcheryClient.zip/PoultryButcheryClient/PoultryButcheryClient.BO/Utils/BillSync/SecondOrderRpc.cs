﻿using BO.BO.Bill;
using Forks.JsonRpc.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using PoultryButcheryClient.BO.Utils;

namespace BO.Utils.BillRpc
{
  public static class SecondOrderRpc
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();
    public static List<SecondOrder> GetSecondOrderList(DateTime date)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/SecondOrderRpc/SyncSecondOrder";
      var result = RpcFacade.Call<string>(method, date);
      return serializer.Deserialize<List<SecondOrder>>(result);
    }

    public static void Insert(SecondOrder_Detail detail, SecondOrder order)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/SecondOrderRpc/InsertDetail";
      var dJson = serializer.Serialize(detail);
      string mJson = string.Empty;
      if (detail.SecondOrder_ID == 0)
        mJson = serializer.Serialize(order);
      order.ID = RpcFacade.Call<long>(method, dJson, mJson, order.OrderDetail_ID);
    }

    public static void DeleteDetail(SecondOrder_Detail detail)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/SecondOrderRpc/DeleteDetail";
      RpcFacade.Call<int>(method, detail.ID, detail.SecondOrder_ID, detail.Number);
    }

    public static void SetFinish(long id,long orderDetailID, SecondOrder order)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/SecondOrderRpc/SetFinish";
      string mJson = string.Empty;
      if (id == 0)
        mJson = serializer.Serialize(order);
      var r = RpcFacade.Call<long>(method, id, orderDetailID, mJson);
      if (id == 0)
        order.ID = r;
    }

    public static List<SecondOrder_Detail> GetSecondOrderDetails(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/SecondOrderRpc/GetSecondOrderDetails";
      var result = RpcFacade.Call<string>(method, id);
      result = result.ESerializeDateTime();
      return serializer.Deserialize<List<SecondOrder_Detail>>(result);
    }
  }
}
