﻿using Forks.JsonRpc.Client;
using Newtonsoft.Json;
using PoultryButcheryClient.BO.BO.Bill;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Forks.JsonRpc.Client.Data;

namespace PoultryButcheryClient.BO.Utils.BillSync
{
    public static class WorkShopRecordRpc
    {


    public  static WorkShopRecord LoadDmo(long id) {


        string jsonStr = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/WorkShopRecordRpc/GetRecordByID", id); ;

        var record = JsonConvert.DeserializeObject<WorkShopRecord>(jsonStr);
        return record;
    }
        public static Tuple<long, string> Insert(WorkShopRecord record)
        {
            //提交当前电脑的标识
            record.BiaoShi = ButcherAppContext.Context.UserConfig.BiaoShi;
            var jsonStr = JsonConvert.SerializeObject(record);
            var result =
                RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/WorkShopRecordRpc/Insert",
                    jsonStr);
            var strArray = result.Split('|');
            if (strArray.Count() == 2)
            {
                return new Tuple<long, string>(long.Parse(strArray[0]), strArray[1]);
            }
            else
            {
                throw  new Exception("没上传成功");
            }

            
        }


        //当切换存货的时候 查询
        public static List<WorkShopRecord> GetUnCompletedList(long goodID)
        {
            var biaoshi = ButcherAppContext.Context.UserConfig.BiaoShi;
            string jsonStr = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/WorkShopRecordRpc/GetUnCompletedList", biaoshi, goodID); ;

            var list = JsonConvert.DeserializeObject<List<WorkShopRecord>>(jsonStr);
            return list;
        }
        //点击结束按钮的时候 将当前存货未完成信息提交
        //注：可能用不到 ，可能在点击结束时生成一个单据时 在服务器d端修改

        public static void SetFinshedGoods(long goodID)
        {
            var biaoshi = ButcherAppContext.Context.UserConfig.BiaoShi;
            string jsonStr = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/WorkShopRecordRpc/GetUnCompletedList", biaoshi, goodID); 
        }

        public static List<WorkShopRecord> GetCompletedBillList(long goodID = 0)
        {
            var biaoshi = ButcherAppContext.Context.UserConfig.BiaoShi;
            string jsonStr = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/WorkShopRecordRpc/GetCompletedList", biaoshi, goodID); ;

            var list = JsonConvert.DeserializeObject<List<WorkShopRecord>>(jsonStr);
            return list;
        }
    }



    public static class WorkShopPackBillRpc
    {


        //当 装箱完毕（装满一车）后 生成一个单据 -- 车间包装单据

        public static Tuple<long, int> InsertPackBill(List<WorkShopRecord> list, out string chaCarCode)
        {
            var barDto = new List<WorkShopRecordBarCodeDto>();
            foreach (var group in list.GroupBy(x => new { x.PlanNumber, x.Goods_Name }))
            {
                var barRecordDto = new WorkShopRecordBarCodeDto();
                barRecordDto.G = group.Key.Goods_Name;
                barRecordDto.P = group.Key.PlanNumber;
                barRecordDto.N = group.Sum(x => x.Number ?? 0);
                barDto.Add(barRecordDto);

            }

           var barDtoString = JsonConvert.SerializeObject(barDto);
            long goodsID = 0;
            if (list.Count > 0)
            {
                goodsID = list.FirstOrDefault().Goods_ID;
            }

            var c = ButcherAppContext.Context.UserConfig;
            var dmo = new RpcObject("/MainSystem/PoultryButcheryClientService/RpcBo/WorkShopPackBill");
            dmo.Set("AccountingUnit_ID", c.AccountingUnit_ID);
            dmo.Set("Department_ID", c.Department_ID);
            dmo.Set("CreateUser_Name", c.UserName);
            var allRecord = list.Select(x=> x.ID).ToList();//存放所有的中间服务器 记录ID


            var allIDsStr = string.Join("|", allRecord);
            var result = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/BillRpc/WorkShopPackBillRpc/InsertPackBill", dmo,goodsID, allIDsStr, barDtoString);

            var strArray = result.Split('|');
            if (strArray.Count() == 2)
            {
                var id = long.Parse(strArray[0]);
                var all = new WorkShopBarCodeDto();
                all.ID = id;
                all.D = barDto;
                chaCarCode = JsonConvert.SerializeObject(all);



                return new Tuple<long, int>(id, int.Parse(strArray[1]));
            }
            else
            {
                throw new Exception("没上传成功");
            }



    
        }

        [Serializable]
        class WorkShopBarCodeDto
        {


            public long? ID { get; set; }
            public List<WorkShopRecordBarCodeDto> D { get; set; }

        }
        [Serializable]
        class WorkShopRecordBarCodeDto
        {

            public string G { get; set; }
            public decimal? N { get; set; }
            public string P { get; set; }



        }




    }
}
