﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using BWP.WinFormControl;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using Newtonsoft.Json;
using PoultryButcheryClient.BO.BO.Bill;

namespace PoultryButcheryClient.BO.Utils.BillSync
{
  public class HandoverRecordRpc
  {

    public static void DeleteLastRecord(string calculateGoodsName, string planNumber)
    {
      var biaoshi= ButcherAppContext.Context.UserConfig.BiaoShi;
      RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/HandoverRecordRpc/DeleteLastRecord", biaoshi, calculateGoodsName, planNumber);
    }

    public static List<HandoverRecordForUi> GetList(string calculateGoodsName="", string planNumber = "")
    {
      var biaoshi = ButcherAppContext.Context.UserConfig.BiaoShi;
      string jsonStr;
      if (!string.IsNullOrWhiteSpace(calculateGoodsName))
      {
        jsonStr= RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/HandoverRecordRpc/GetList", biaoshi, calculateGoodsName, planNumber);
      }
      else
      {
        jsonStr = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/HandoverRecordRpc/GetAllList", biaoshi, planNumber);
      }
      var list = JsonConvert.DeserializeObject<List<HandoverRecord>>(jsonStr);
      var uiList = GetUiList(list);
      return uiList;
    }

    private static List<HandoverRecordForUi> GetUiList(List<HandoverRecord> handoverRecords)
    {
      var list=new List<HandoverRecordForUi>();
      foreach (var group in handoverRecords.GroupBy(x => new { x.CalculateGoods_ID , x.PlanNumber}))
      {
          var rui = new HandoverRecordForUi();
          rui.CalculateGoods_ID = group.Key.CalculateGoods_ID;
          rui.CalculateGoods_Name = group.Last().CalculateGoods_Name;
          rui.Goods_ID = group.First().Goods_ID;
          rui.CalculateSpec_Name = group.First().CalculateSpec_Name;
          rui.PlanNumber = group.Key.PlanNumber;
          foreach (HandoverRecord record in group)
          {
              var detail = new HandoverRecordDetailForUi();
              detail.HandoverRecordID = record.ID;          
              detail.InputNumber = (record.InputNumber);
              detail.MainUnitRatio = record.MainUnitRatio ?? 0;
              detail.SecondIINumber = record.SecondIINumber ?? 0;
              detail.Weight = record.Weight ?? 0;

              rui.Details.Add(detail);
          }
          list.Add(rui);
      }

      return list;
    }

    public static long Insert(HandoverRecord record)
    {
      //提交当前电脑的标识
      record.BiaoShi = ButcherAppContext.Context.UserConfig.BiaoShi;
      var jsonStr = JsonConvert.SerializeObject(record);
      var id = RpcFacade.Call<long>("/MainSystem/PoultryButcheryClientService/Rpcs/HandoverRecordRpc/Insert", jsonStr);
      return id;
    }
    public static long Insert(ManualInput manualInput, string planNumber)
    {
        var record = GetByManualInput(manualInput, planNumber);
      return Insert(record);
    }

    static HandoverRecord GetByManualInput(ManualInput manualInput, string planNumber)
    {
      var record=new HandoverRecord();
      record.CalculateGoods_Name = manualInput.CalculateGoods_Name;
        record.CalculateGoods_ID = manualInput.CalculateGoods_ID;
      record.CalculateSpec_Name = manualInput.CalculateSpec_Name;
      record.InputNumber = manualInput.InputNumber;
      record.MainUnitRatio = manualInput.MainUnitRatio;
      record.SecondUnitII_MainUnitRatio = manualInput.SecondUnitII_MainUnitRatio;
      record.IsSecondⅡ = false;
      record.Goods_ID = manualInput.Goods_ID;
      record.PlanNumber = planNumber;
      return record;
    }


  }
}
