﻿using BO.BO.BaseInfo;
using BO.BO.Bill;
using Forks.JsonRpc.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using PoultryButcheryClient.BO;
using PoultryButcheryClient.BO.Utils;

namespace BO.Utils.BillRpc
{
  public static class GradeAndWeightRpc
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();

    public static List<GradeAndWeight> GetGradeAndWeightList(DateTime date, long? maxID = null)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/GetGradeAndWeightList";
      var result = RpcFacade.Call<string>(method, date, maxID);
      return serializer.Deserialize<List<GradeAndWeight>>(result);
    }

    public static List<GradeAndWeight_Detail> GetDetails(DateTime date, int top = 15)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/GetDetailsList";
      var result = RpcFacade.Call<string>(method, date, top);
      result = result.ESerializeDateTime();
      return serializer.Deserialize<List<GradeAndWeight_Detail>>(result);
    }

    public static void UpdateOrInsertDetail(GradeAndWeight_Detail detail, bool fillTechnics = false)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/UpdateOrInsertDetail";
      detail.ID = RpcFacade.Call<long>(method, serializer.Serialize(detail), fillTechnics);
    }

    public static void UpdateLivestock(long id, long liveStockID, string liveStockName, short technics, string technicsName)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/UpdateLivestock";
      RpcFacade.Call<int>(method, id, liveStockID, liveStockName, technics, technicsName);
    }

    public static void SetGradeFinish(long orderDetailID, short technics)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/SetGradeFinish";
      RpcFacade.Call<int>(method, orderDetailID, technics);
    }

    public static List<BodyDiscontItem> GetBodyDiscontItem()
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/GetBodyDiscontItemSetting";
      var json = RpcFacade.Call<string>(method);
      return serializer.Deserialize<List<BodyDiscontItem>>(json);
    }

    public static void SaveBodyDiscontItem(List<CTuple<long, decimal?>> list)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/SaveBodyDiscontItemSetting";
      RpcFacade.Call<int>(method, serializer.Serialize(list));
    }

    public static void UpdateWeight(long id, decimal? weight)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/GradeAndWeightRpc/UpdateWeight";
      RpcFacade.Call<int>(method, id, weight);
    }
  }
}
