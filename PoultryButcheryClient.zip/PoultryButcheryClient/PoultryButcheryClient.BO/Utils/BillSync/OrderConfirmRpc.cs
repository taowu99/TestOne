﻿using BO.BO.Bill;
using Forks.JsonRpc.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace BO.Utils.BillRpc
{
  public static class OrderConfirmRpc
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();
    public static List<ConfirmOrder> GetConfirmOrder(DateTime date)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderConfirmRpc/GetConfirmOrder";
      var json = RpcFacade.Call<string>(method, date);
      return serializer.Deserialize<List<ConfirmOrder>>(json);
    }

    public static void SetOrderConfirmed(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderConfirmRpc/SetOrderConfirmed";
      RpcFacade.Call<int>(method, id);
    }
  }
}
