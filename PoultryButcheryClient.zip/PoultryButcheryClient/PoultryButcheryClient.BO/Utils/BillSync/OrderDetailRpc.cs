﻿using BO.BO.Bill;
using Forks.JsonRpc.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using BO.Utils;
using PoultryButcheryClient.BO.Utils;

namespace BO.Utils.BillRpc
{
  public static class OrderDetailRpc
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();
    public static List<NeedOrderEntity> GetNeedOrderWeightBill(DateTime date, bool? showType = null)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/GetNeedOrderWeightBill";
      var result = RpcFacade.Call<string>(method, date, showType);
      result = result.ESerializeDateTime();
      return serializer.Deserialize<List<NeedOrderEntity>>(result);
    }

    public static int GetLastNumber(long weightId, long orerID)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/GetLastNumber";
      return RpcFacade.Call<int>(method, weightId, orerID);
    }

    public static int GetMaxOrder(DateTime date)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/GetMaxOrder";
      return RpcFacade.Call<int>(method, date);
    }

    public static int GetCurrentOrder(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/GetCurrentOrder";
      return RpcFacade.Call<int>(method, id);
    }

    public static List<OrderDetail> GetOrderDetail(DateTime date, int? minOrder = null)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/GetOrderDetail";
      var result = RpcFacade.Call<string>(method, date, minOrder);
      result = result.ESerializeDateTime();
      return serializer.Deserialize<List<OrderDetail>>(result);
    }

    public static void Insert(OrderDetail insert)
    {
      insert.AccountingUnit_ID = ButcherAppContext.Context.UserConfig.AccountingUnit_ID;
      insert.Creator = ButcherAppContext.Context.UserConfig.UserName;
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/Insert";
      insert.ID = RpcFacade.Call<long>(method, serializer.Serialize(insert));
    }

    public static void UpdateNumber(long id, int number)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/UpdateNum";
      RpcFacade.Call<int>(method, id, number);
    }

    public static void UpdateHurryFlag(long id, bool flag)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/UpdateHurryFlag";
      RpcFacade.Call<int>(method, id, flag);
    }

    public static void Delete(long id)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/Delete";
      RpcFacade.Call<int>(method, id);
    }

    public static void ChangeShowType(long weightBillID, bool show)
    {
      const string method = "/MainSystem/B3ClientService/Rpcs/BillRpc/OrderDetailRpc/ChangeShowType";
      RpcFacade.Call<int>(method, weightBillID, show);
    }
  }
}
