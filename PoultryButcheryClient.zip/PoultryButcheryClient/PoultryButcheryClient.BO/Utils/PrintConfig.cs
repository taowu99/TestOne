﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoultryButcheryClient.BO.Utils
{
    public class PrintConfig
    {
        public int PrintType { get; set; }//0 立象打印机 ，1 斑马打印机    后期可以删除

        public string PrintName { get; set; }//斑马打印机的打印名称

        public int ComPort { get; set; }//斑马打印机链接的com端口
        public string TemplateRecordName { get; set; }//斑马打印机的模板的名称


        public string TemplateBillName { get; set; }//斑马打印机的模板的名称
        public int? PrintSpeed { get; set; }//使用斑马打印机打印的时候 设置每几秒发送 ZPL命令到 打印机上。 当为空或0的时候默认为 3
    }
}
