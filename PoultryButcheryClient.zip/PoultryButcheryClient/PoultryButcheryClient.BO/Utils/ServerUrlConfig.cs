﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoultryButcheryClient.BO.Utils
{
  public class ServerUrlConfig
  {
    public string ServerUrl { get; set; }
  }
}
