﻿using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoultryButcheryClient.BO.Utils
{
  public class LoginRpcUtil
  {
    public static string GetUserNameByCode(string code, out string error)
    {
      try
      {
        error = string.Empty;
        const string wpfUserMethod = "/MainSystem/PoultryButcheryClientService/Rpcs/UserInfoRpc/GetUserName";
        return RpcFacade.Call<string>(wpfUserMethod, code);
      }
      catch (Exception ex)
      {
        error = ex.ToString();
      }
      return string.Empty;
    }

    public static void FillUserEmpInfo(string name, LoginUserInfo userInfo)
    {
      const string wpfUserMethod = "/MainSystem/PoultryButcheryClientService/Rpcs/UserInfoRpc/GetUserEmpInfo";
      var obj = RpcFacade.Call<RpcObject>(wpfUserMethod, name);
      if (obj != null)
      {
        userInfo.ID = obj.Get<long>("User_ID");
        userInfo.UserName = obj.Get<string>("User_Name");
        userInfo.Domain_ID = obj.Get<long>("Domain_ID");
        userInfo.AccountingUnit_ID = obj.Get<long?>("AccountingUnit_ID");
        userInfo.AccountingUnit_Name = obj.Get<string>("AccountingUnit_Name");
        userInfo.Department_ID = obj.Get<long?>("Department_ID");
        userInfo.Department_Name = obj.Get<string>("Department_Name");
        userInfo.Employee_ID = obj.Get<long>("Employee_ID");
        userInfo.Employee_Name = obj.Get<string>("Employee_Name");
        userInfo.Role = obj.Get<string>("Role");
      }
    }
  }
}
