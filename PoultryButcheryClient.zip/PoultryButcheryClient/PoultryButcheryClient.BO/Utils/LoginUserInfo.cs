﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoultryButcheryClient.BO.Utils
{
  public class LoginUserInfo
  {
    public long ID { get; set; }

    public string EmpCode { get; set; }
    public string Pwd { get; set; }

    public string UserName { get; set; }

    public long Domain_ID { get; set; }

    public long? AccountingUnit_ID { get; set; }

    public string AccountingUnit_Name { get; set; }

    public long? Department_ID { get; set; }

    public string Department_Name { get; set; }

    public long Employee_ID { get; set; }

    public string Employee_Name { get; set; }

    public string Role { get; set; }

    public string BiaoShi { get; set; }

    public string FuctionName { get; set; }

      public long Store_ID { get; set; }
      public string Store_Name { get; set; }
      public string PlanNumber { get; set; }
  }
}
