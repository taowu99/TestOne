﻿using System;
using System.Text.RegularExpressions;

namespace PoultryButcheryClient.BO.Utils
{
  public static class ConvertUtil
  {
    public static string ESerializeDateTime(this string json)
    {
      return Regex.Replace(json, @"\\/Date\((\d+)\)\\/", match =>
      {
        DateTime dt = new DateTime(1970, 1, 1);
        dt = dt.AddMilliseconds(long.Parse(match.Groups[1].Value));
        dt = dt.ToLocalTime();
        return dt.ToString("yyyy-MM-dd HH:mm:ss");
      });
    }
  }
}
