﻿using System.IO;
using System.Windows.Forms;

namespace PoultryButcheryClient.BO.Utils
{
  public class ButcherAppContext
  {
    private static string loginConfigPath = Application.StartupPath + "\\Config.xml";
    public ServerUrlConfig UrlConfig
    {
      get;
      set;
    }

    public LoginUserInfo UserConfig
    {
      get;
      set;
    }

    public PrintConfig PrConfig
      {
          get;
          set;
      }
      

    private ButcherAppContext()
    {
      UrlConfig = new ServerUrlConfig();
      UserConfig = new LoginUserInfo();
        PrConfig = new PrintConfig();

    }

    public static ButcherAppContext Context
    {
      get
      {
        if (_appContext == null)
          _appContext = CreateAppContext();
        return _appContext;
      }
    }

    private static ButcherAppContext _appContext;
    static ButcherAppContext CreateAppContext()
    {
      var config = new ButcherAppContext();
      if (!File.Exists(loginConfigPath))
      {
        XmlUtil.SerializerObjToFile(config, loginConfigPath);
      }
      else
        config = XmlUtil.DeserializeFromFile<ButcherAppContext>(loginConfigPath);
      return config;
    }

    public void Save()
    {
      XmlUtil.SerializerObjToFile(_appContext, loginConfigPath);
    }
  }
}
