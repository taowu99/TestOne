﻿using System;
using System.Collections.Generic;
using System.Web.Script.Serialization;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using Newtonsoft.Json;
using PoultryButcheryClient.BO.BO.BaseInfo;

namespace PoultryButcheryClient.BO.Utils
{
  public static class BaseInfoRpcUtil
  {
    static JavaScriptSerializer serializer = new JavaScriptSerializer();





    public static long InsertCalculateSpec(string spec)
    {
      var id = RpcFacade.Call<long>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/InsertCalculateSpec", spec);
      return id;
    }

    public static List<PlanNoBaseInfo> GetPlanNoBaseInfo()
    {
        var strJson = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetPlanNoBaseInfos");
        var list = JsonConvert.DeserializeObject<List<PlanNoBaseInfo>>(strJson);
        return list;
    }

      public static List<Store> GetStoreBaseInfo()
      {
          var strJson = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetStoreBaseInfos");
          var list = JsonConvert.DeserializeObject<List<Store>>(strJson);
          return list;
      }

    public static List<CalculateSpec> GetCalculateSpecs()
    {
      var strJson= RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetCalculateSpecs");
      var list = JsonConvert.DeserializeObject<List<CalculateSpec>>(strJson);
      return list;
    }

    public static List<Tuple<string, string>> GetBaseInfoEntity(string rpcName)
    {
      var list = RpcFacade.Call<List<RpcObject>>(string.Format("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/{0}", rpcName), null, null, -1);
      var result = new List<Tuple<string, string>>();
      foreach (RpcObject o in list)
      {
        var entity = new Tuple<string, string>(o.Get<string>("PhyName"), o.Get<string>("DisplayName"));
        result.Add(entity);
      }
      return result;
    }

    public static List<Tuple<long, long, string>> GetSanctionList()
    {
      var list = RpcFacade.Call<List<RpcObject>>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetSanctionList");
      var result = new List<Tuple<long, long, string>>();
      foreach (RpcObject o in list)
      {
        var entity = new Tuple<long, long, string>(o.Get<long>("ID"), o.Get<long>("AbnormalItem_ID"), o.Get<string>("AbnormalItem_Name"));
        result.Add(entity);
      }
      return result;
    }

    public static List<CTuple<long, string, short>> GetLivestockList()
    {
      var list = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetLivestock");
      return serializer.Deserialize<List<CTuple<long, string, short>>>(list);
    }
  }
}
