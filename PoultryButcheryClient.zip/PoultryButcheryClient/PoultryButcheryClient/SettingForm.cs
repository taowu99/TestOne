﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Forks.JsonRpc.Client;
using PoultryButcheryClient.BO.Utils;

namespace PoultryButcheryClient
{
  public partial class SettingForm : Form
  {
    bool mInited;
    public SettingForm(bool rpcFacadeInited)
    {
      InitializeComponent();
      uTextBoxWithPad1.Text = ButcherAppContext.Context.UrlConfig.ServerUrl;
      mInited = rpcFacadeInited;
    }

    private void cancelBtn_Click(object sender, EventArgs e)
    {
      Close();
    }

    private void saveBtn_Click(object sender, EventArgs e)
    {
      string uri = this.uTextBoxWithPad1.Text.Trim();
      if (string.IsNullOrEmpty(uri))
        throw new Exception("请先设置服务器地址");
      ButcherAppContext.Context.UrlConfig.ServerUrl = uri;
      ButcherAppContext.Context.Save();

      if (mInited)
        RpcFacade.ReInit(ButcherAppContext.Context.UrlConfig.ServerUrl);
      MessageBox.Show("设置保存成功!");
    }

    private void SettingForm_Load(object sender, EventArgs e)
    {

    }
  }
}
