﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using PoultryButcheryClient.BO.Utils;

namespace PoultryButcheryClient
{
  public partial class FunctionForm : Form, IAfterLoginForm
  {
    public FunctionForm()
    {
      InitializeComponent();
    }

    private void FunctionForm_Load(object sender, EventArgs e)
    {
      var list = RpcFacade.Call<List<RpcObject>>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetAllWorkshopCategoryList");
      foreach (var obj in list)
      {
        var btn = new Button() { Text = obj.Get<string>("Name") };
        btn.Font = new System.Drawing.Font("宋体", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
        btn.Size = new System.Drawing.Size(200, 200);
        btn.UseVisualStyleBackColor = true;
        btn.Click += Btn_Click;

        btn.Tag = obj;
        flowLayoutPanel1.Controls.Add(btn);
      }
    }

    private void Btn_Click(object sender, EventArgs e)
    {
      var obj = (RpcObject)(sender as Button).Tag;
      var ifweight = obj.Get<bool?>("IfWeight");
      if (ifweight == null)
      {
        ifweight = false;
      }
      var form = AfterLoginUtil.CreateStatisticalManualForm(ifweight.Value ? InputType.Weight : InputType.Manual, obj.Get<string>("Name"));
      if (form == null)
        throw new Exception("输入类型不符");
      form.FormClosing += delegate { SubFormClosing(); };
      form.Show();
      Hide();
    }
    void SubFormClosing()
    {
      foreach (Form form in Application.OpenForms)
      {
        if (form is FunctionForm)
        {
          form.Show();
          return;
        }
      }
    }

    public Form Generate()
    {
        return this;
    }
  }
}
