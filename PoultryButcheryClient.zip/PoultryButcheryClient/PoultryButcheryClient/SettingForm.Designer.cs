﻿namespace PoultryButcheryClient
{
  partial class SettingForm
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.cancelBtn = new System.Windows.Forms.Button();
      this.saveBtn = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.uTextBoxWithPad1 = new BWP.WinFormControl.UTextBoxWithPad();
      this.SuspendLayout();
      // 
      // cancelBtn
      // 
      this.cancelBtn.Font = new System.Drawing.Font("宋体", 20F);
      this.cancelBtn.Location = new System.Drawing.Point(301, 109);
      this.cancelBtn.Name = "cancelBtn";
      this.cancelBtn.Size = new System.Drawing.Size(81, 53);
      this.cancelBtn.TabIndex = 10;
      this.cancelBtn.Text = "关闭";
      this.cancelBtn.UseVisualStyleBackColor = true;
      this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
      // 
      // saveBtn
      // 
      this.saveBtn.Font = new System.Drawing.Font("宋体", 20F);
      this.saveBtn.Location = new System.Drawing.Point(149, 109);
      this.saveBtn.Name = "saveBtn";
      this.saveBtn.Size = new System.Drawing.Size(81, 53);
      this.saveBtn.TabIndex = 9;
      this.saveBtn.Text = "保存";
      this.saveBtn.UseVisualStyleBackColor = true;
      this.saveBtn.Click += new System.EventHandler(this.saveBtn_Click);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("宋体", 15F);
      this.label1.Location = new System.Drawing.Point(12, 43);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(129, 20);
      this.label1.TabIndex = 8;
      this.label1.Text = "服务器地址：";
      // 
      // uTextBoxWithPad1
      // 
      this.uTextBoxWithPad1.Font = new System.Drawing.Font("宋体", 20F);
      this.uTextBoxWithPad1.Location = new System.Drawing.Point(132, 34);
      this.uTextBoxWithPad1.Name = "uTextBoxWithPad1";
      this.uTextBoxWithPad1.Size = new System.Drawing.Size(387, 38);
      this.uTextBoxWithPad1.TabIndex = 11;
      this.uTextBoxWithPad1.Type = BWP.WinFormControl.UTextBoxWithPad.TextBoxType.Normal;
      // 
      // SettingForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(545, 205);
      this.Controls.Add(this.uTextBoxWithPad1);
      this.Controls.Add(this.cancelBtn);
      this.Controls.Add(this.saveBtn);
      this.Controls.Add(this.label1);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "SettingForm";
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
      this.Text = "设置服务器地址";
      this.Load += new System.EventHandler(this.SettingForm_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button cancelBtn;
    private System.Windows.Forms.Button saveBtn;
    private System.Windows.Forms.Label label1;
    private BWP.WinFormControl.UTextBoxWithPad uTextBoxWithPad1;
  }
}