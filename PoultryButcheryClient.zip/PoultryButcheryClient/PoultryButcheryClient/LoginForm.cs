﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Forks.JsonRpc.Client;
using PoultryButcheryClient.BO.Utils;

namespace PoultryButcheryClient
{
  public partial class LoginForm : Form
  {
    public LoginForm()
    {
      InitializeComponent();
    }

    bool rpcFacadeInited = false;

    void IniteRpcFacade()
    {
      if (rpcFacadeInited)
        return;
      if (string.IsNullOrEmpty(ButcherAppContext.Context.UrlConfig.ServerUrl))
        throw new Exception("请先设置服务器地址");
      RpcFacade.Init(ButcherAppContext.Context.UrlConfig.ServerUrl, "B3PoultryButcheryClient");
      rpcFacadeInited = true;
    }

    private async void loginBtn_Click(object sender, EventArgs e)
    {
      var biaoshi = txtBiaoShi.Text;
      if (string.IsNullOrWhiteSpace(biaoshi))
      {
        MessageBox.Show("标识不能为空");
        return;
      }
      var c = ButcherAppContext.Context.UserConfig;

      var empcode = userNameTxt.Text.Trim();
      if (string.IsNullOrEmpty(empcode))
        throw new Exception("请输入用户编号");

      IniteRpcFacade();
      //SG001
      var username = RpcFacade.Call<string>("/MainSystem/PoultryButcheryClientService/Rpcs/BaseInfoRpc/GetUserNameByEmployeeCode", empcode);
      var pwd = pwdTxt.Text;



      await Task.Factory.StartNew(() => RpcFacade.Login(username, pwd));
      c.EmpCode = empcode;
      c.Pwd = pwd;
      c.BiaoShi = biaoshi.Trim();
      LoginRpcUtil.FillUserEmpInfo(username, c);
      ButcherAppContext.Context.Save();

    

      //      var form = AfterLoginUtil.CreateForm(ButcherAppContext.Context.UserConfig.Role);
      //      if (form == null)
      //        throw new Exception("权限不符");
        Form form = null;
        if (c.FuctionName == "WorkShopPack")
        {          
            form = AfterLoginUtil.CreateAfterLoginForm(c.FuctionName); 
        } else 
        {
            form = new FunctionForm();
        }
     
      form.FormClosing += delegate { SubFormClosing(); };
      form.Show();
      Hide();
    }

    void SubFormClosing()
    {
      foreach (Form form in Application.OpenForms)
      {
        if (form is LoginForm)
        {
          form.Show();
          return;
        }
      }
    }

    private void settingBtn_Click(object sender, EventArgs e)
    {
      var f = new SettingForm(rpcFacadeInited);
      f.ShowDialog();
    }

    private void closeBtn_Click(object sender, EventArgs e)
    {
      Application.Exit();
    }

    private void LoginForm_Load(object sender, EventArgs e)
    {
      var c = ButcherAppContext.Context.UserConfig;
      if (!string.IsNullOrWhiteSpace(c.EmpCode))
      {
        userNameTxt.Text = c.EmpCode;
      }
      if (!string.IsNullOrWhiteSpace(c.Pwd))
      {
        pwdTxt.Text = c.Pwd;
      }
      txtBiaoShi.Text = c.BiaoShi;
    }
  }
}
