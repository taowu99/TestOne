﻿namespace BWP.WinFormControl
{
  partial class ManualSetControl
  {
    /// <summary> 
    /// 必需的设计器变量。
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// 清理所有正在使用的资源。
    /// </summary>
    /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region 组件设计器生成的代码

    /// <summary> 
    /// 设计器支持所需的方法 - 不要修改
    /// 使用代码编辑器修改此方法的内容。
    /// </summary>
    private void InitializeComponent()
    {
            this.lblDisplay = new System.Windows.Forms.Label();
            this.cbxSelected = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // lblDisplay
            // 
            this.lblDisplay.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblDisplay.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblDisplay.Location = new System.Drawing.Point(3, 2);
            this.lblDisplay.Name = "lblDisplay";
            this.lblDisplay.Size = new System.Drawing.Size(183, 78);
            this.lblDisplay.TabIndex = 0;
            this.lblDisplay.Text = "存货斯蒂芬森";
            this.lblDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblDisplay.Click += new System.EventHandler(this.lblDisplay_Click);
            // 
            // cbxSelected
            // 
            this.cbxSelected.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cbxSelected.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbxSelected.Location = new System.Drawing.Point(192, 3);
            this.cbxSelected.Name = "cbxSelected";
            this.cbxSelected.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cbxSelected.Size = new System.Drawing.Size(72, 79);
            this.cbxSelected.TabIndex = 1;
            this.cbxSelected.UseVisualStyleBackColor = true;
            this.cbxSelected.CheckedChanged += new System.EventHandler(this.cbxSelected_CheckedChanged);
            this.cbxSelected.Click += new System.EventHandler(this.cbxSelected_Click);
            // 
            // ManualSetControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.cbxSelected);
            this.Controls.Add(this.lblDisplay);
            this.Name = "ManualSetControl";
            this.Size = new System.Drawing.Size(263, 81);
            this.Load += new System.EventHandler(this.ManualSetControl_Load);
            this.Click += new System.EventHandler(this.ManualSetControl_Click);
            this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Label lblDisplay;
    private System.Windows.Forms.CheckBox cbxSelected;
  }
}
