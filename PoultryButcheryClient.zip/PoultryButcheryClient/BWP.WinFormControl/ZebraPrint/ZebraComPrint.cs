﻿using System;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;

namespace BWP.WinFormControl
{
 
    public class ZebraComPrint
    {
        private SerialPort sp;
        private string portName;
        private int baudRate;
        private Parity parity;
        private int dataBits;
        private StopBits stopBits;
        public ZebraComPrint(int portName, int baudRate, Parity parity, int dataBits, StopBits stopBits)
        {
            sp = new SerialPort("COM" + portName, baudRate, parity, dataBits, stopBits);
        }

        public ZebraComPrint(int portName)
        {
            sp = new SerialPort("COM" + portName, 9600, Parity.None, 8, StopBits.One);
            
        }

        public bool Open()
        {
            if (sp.IsOpen)
            {
                return true;
            }
            else
            {
                try
                {
                    sp.Open();
                    return true;
                }
                catch
                {
                    return false;
                }
            }

        }

        public bool IsOpen()
        {
            if (sp.IsOpen)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Close()
        {
            if (sp.IsOpen)
            {
                try
                {
                    sp.Close();
                    sp.Dispose();
                    return true;
                }
                catch
                {
                    return false;
                }

            }
            else
            {
                return true;
            }
        }


        public bool Write(string str)
        {
            try
            {
                byte[] mybyte = System.Text.Encoding.Default.GetBytes(str);
                sp.Write(mybyte, 0, mybyte.Length);

                return true;
            }
            catch
            {
                return false;
            }

        }



    }
}
