﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Management;
using System.IO;

namespace BWP.WinFormControl
{
  

    public class ZebraUSBPrint
    {

        [System.Runtime.InteropServices.StructLayout(System.Runtime.InteropServices.LayoutKind.Sequential)]
        private struct OVERLAPPED { int Internal; int InternalHigh; int Offset; int OffSetHigh; int hEvent;      }
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        private static extern int CreateFile(string lpFileName, uint dwDesiredAccess, int dwShareMode, int lpSecurityAttributes, int dwCreationDisposition, int dwFlagsAndAttributes, int hTemplateFile);
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        private static extern bool WriteFile(int hFile, byte[] lpBuffer, int nNumberOfBytesToWrite, out   int lpNumberOfBytesWritten, out   OVERLAPPED lpOverlapped);
        [System.Runtime.InteropServices.DllImport("kernel32.dll")]
        private static extern bool CloseHandle(int hObject);
        private int iHandle;
        string pnpDeviceID;
        public ZebraUSBPrint(string pnpDeviceID)
        {
            iHandle = -1;
            this.pnpDeviceID = pnpDeviceID;
        }

        public List<string> GetPnpDeviceID()
        {
            var list = new List<string>();
            SelectQuery selectQuery = new SelectQuery("Win32_USBHub");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(selectQuery);
            foreach (ManagementObject disk in searcher.Get())
            {
                //PNPDeviceID
                string devicename = disk["name"] as string;
//                if (!(devicename.Contains("打印") || devicename.Contains("Print") || devicename.Contains("print")))
//                {
//                    continue;
//                }
                list.Add(disk["PNPDeviceID"] as String);
 


            }
            return list;
        }
        public ZebraUSBPrint(out string pnpDeviceID)
        {
            iHandle = -1;
            SelectQuery selectQuery = new SelectQuery("Win32_USBHub");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(selectQuery);
            foreach (ManagementObject disk in searcher.Get())
            {
                //PNPDeviceID
                string devicename = disk["name"] as string;
                if (!(devicename.Contains("打印") || devicename.Contains("Print") || devicename.Contains("print")))
                {
                    continue;
                }
                this.pnpDeviceID = disk["PNPDeviceID"] as String;
                break;

            }
            pnpDeviceID = this.pnpDeviceID;


        }

        public ZebraUSBPrint()
        {
            iHandle = -1;
            SelectQuery selectQuery = new SelectQuery("Win32_USBHub");
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(selectQuery);
            foreach (ManagementObject disk in searcher.Get())
            {
                //PNPDeviceID
                string devicename = disk["name"] as string;
                if (!(devicename.Contains("打印") || devicename.Contains("Print") || devicename.Contains("print")))
                {
                    continue;
                }
                this.pnpDeviceID = disk["PNPDeviceID"] as String;
                break;

            }
        }

        //打开LPT 端口
        //    public bool Open()
        //    {
        //        SelectQuery selectQuery = new SelectQuery("Win32_USBHub");
        //        ManagementObjectSearcher searcher = new ManagementObjectSearcher(selectQuery);
        //        iHandle = -1;
        //        foreach (ManagementObject disk in searcher.Get())
        //        {
        //            //PNPDeviceID
        //            string devicename = disk["name"] as string;
        //            if (!(devicename.Contains("打印") || devicename.Contains("Print") || devicename.Contains("print")))
        //                continue;
        //            string PNPDeviceID = disk["PNPDeviceID"] as String;
        //            //if (PNPDeviceID != "USB\\VID_0A5F&PID_00EC\\JJK145170")
        //            //    continue;
        //            iHandle = CreateFile("\\\\.\\" + PNPDeviceID.Replace('\\', '#') + "#{A5DCBF10-6530-11D2-901F-00C04FB951ED}"
        //, (uint)FileAccess.ReadWrite, 0, 0, (int)FileMode.Open, 0, 0);
        //            if (iHandle != -1)
        //            {
        //                return true;
        //            }
        //        }
        //        return false;
        //    }


        public bool Open()
        {
            if (iHandle != -1)
            {
                return true;
            }
            else
            {
                iHandle = CreateFile("\\\\.\\" + pnpDeviceID.Replace('\\', '#') + "#{A5DCBF10-6530-11D2-901F-00C04FB951ED}", (uint)FileAccess.ReadWrite, 0, 0, (int)FileMode.Open, 0, 0);
                if (iHandle != -1)
                {
                    return true;
                }

                return false; 
            }

        }

        //打印函数，参数为打印机的命令或者其他文本！
        public bool Write(string MyString)
        {
            if (iHandle != -1)
            {
                int i;
                OVERLAPPED x;
                byte[] mybyte = System.Text.Encoding.Default.GetBytes(MyString);
                return WriteFile(iHandle, mybyte, mybyte.Length, out i, out x);
            }
            else
            {
                throw new Exception("端口未打开~！");
            }
        }
        //关闭打印端口
        public bool Close()
        {
            return CloseHandle(iHandle);
        }

    }
}
