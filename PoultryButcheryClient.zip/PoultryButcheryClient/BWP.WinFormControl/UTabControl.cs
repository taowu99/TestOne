﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  public class UTabControl : TabControl
  {
    //Image tabBackground;
    //Form parent;

    Font textFont = new Font("宋体", 15);
    Font TextFont { get { return textFont; } set { textFont = value; } }

    public bool FromRightFlow { get; set; }

    #region Initiates

    public UTabControl()
    {
      setStyles();

      //tabBackground = new Bitmap(this.GetType(), "TabButtonBackground.bmp");

      this.Dock = System.Windows.Forms.DockStyle.Fill;
      //this.ItemSize = new System.Drawing.Size(150, 50);
      this.Location = new System.Drawing.Point(0, 0);

      this.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;

      this.ResumeLayout(false);
    }

    #endregion

    #region Private UI Methods

    private void setStyles()
    {
      base.SetStyle(
           ControlStyles.UserPaint |
           ControlStyles.OptimizedDoubleBuffer |
           ControlStyles.AllPaintingInWmPaint |
           ControlStyles.ResizeRedraw |
           ControlStyles.SupportsTransparentBackColor,
           true);
      base.UpdateStyles();
    }

    // 计算控件底线
    //private void setLowBound(Control container)
    //{
    //  int tmp = 0;
    //  Control c = null;
    //  for (int i = 0; i < container.Controls.Count; i++)
    //  {
    //    c = container.Controls[i];
    //    if (tmp < c.Bottom)
    //      tmp = c.Bottom;
    //  }
    //  container.Tag = tmp;
    //}
    #endregion

    #region Tab Overrides
    //protected override void OnControlAdded(ControlEventArgs e)
    //{
    //  setLowBound(e.Control);
    //}

    //protected override void OnSelected(TabControlEventArgs e)
    //{
    //  parent.Text = e.TabPage.Text;
    //}

    //protected override void OnParentChanged(EventArgs e)
    //{
    //  if (parent == null)
    //    parent = this.FindForm();
    //  if (this.TabPages.Count != 0)
    //    parent.Text = this.TabPages[0].Text;
    //}
    #endregion

    #region Paint Override
    protected override void OnPaint(PaintEventArgs e)
    {
      //e.Graphics.TextRenderingHint = TextRenderingHint.AntiAlias;

      for (int i = 0; i < this.TabCount; i++)
      {
        var rectangle = this.GetTabRect(i);
        var textBrush = SystemBrushes.ControlText;
        if (this.SelectedIndex == i)
        {
          textBrush = new System.Drawing.SolidBrush(Color.FromArgb(255, 255, 255));
          e.Graphics.FillPath(new System.Drawing.SolidBrush(Color.FromArgb(66, 163, 218)), GetPath(rectangle));
        }
        //e.Graphics.DrawImage(tabBackground, rectangle);

        SizeF textSize
            = e.Graphics.MeasureString(this.TabPages[i].Text, this.TextFont);

        //e.Graphics.DrawString(
        //    this.TabPages[i].Text,
        //     this.TextFont,
        //    SystemBrushes.ControlLightLight,
        //    rectangle.X + (rectangle.Width - textSize.Width) / 2 + 1,
        //    rectangle.Y + (rectangle.Height - textSize.Height) / 2 + 1);

        e.Graphics.DrawString(
            this.TabPages[i].Text,
             this.TextFont,
            textBrush,
             rectangle.X + (rectangle.Width - textSize.Width) / 2,
            rectangle.Y + (rectangle.Height - textSize.Height) / 2);
      }
    }

    GraphicsPath GetPath(Rectangle rectangle)
    {
      GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
      path.AddLine(rectangle.Left - 1, rectangle.Top, rectangle.Left - 1, rectangle.Top);
      path.AddLine(rectangle.Left - 1, rectangle.Top, rectangle.Right, rectangle.Top);
      path.AddLine(rectangle.Right, rectangle.Top, rectangle.Right, rectangle.Bottom);
      path.AddLine(rectangle.Right, rectangle.Bottom + 1, rectangle.Left - 1, rectangle.Bottom + 1);
      return path;
    }
    #endregion
  }
}
