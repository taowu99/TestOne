﻿using System.Windows.Forms;
namespace BWP.WinFormControl
{
  partial class WeightControl
  {
    /// <summary> 
    /// 必需的设计器变量。
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// 清理所有正在使用的资源。
    /// </summary>
    /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
    protected override void Dispose(bool disposing)
    {
      enableWeightBox.CheckState = CheckState.Unchecked;
      if (weightSerialPort.IsOpen)
      { 
        weightSerialPort.Close();
        weightSerialPort.Dispose();
      }
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region 组件设计器生成的代码

    /// <summary> 
    /// 设计器支持所需的方法 - 不要
    /// 使用代码编辑器修改此方法的内容。
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.panel1 = new System.Windows.Forms.Panel();
      this.weightLabel = new System.Windows.Forms.Label();
      this.enableWeightBox = new System.Windows.Forms.CheckBox();
      this.weightSerialPort = new System.IO.Ports.SerialPort(this.components);
      this.panel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // panel1
      // 
      this.panel1.BackColor = System.Drawing.Color.Black;
      this.panel1.Controls.Add(this.weightLabel);
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(155, 57);
      this.panel1.TabIndex = 0;
      // 
      // weightLabel
      // 
      this.weightLabel.AutoSize = true;
      this.weightLabel.BackColor = System.Drawing.Color.Transparent;
      this.weightLabel.Font = new System.Drawing.Font("宋体", 22F, System.Drawing.FontStyle.Bold);
      this.weightLabel.ForeColor = System.Drawing.Color.Red;
      this.weightLabel.Location = new System.Drawing.Point(5, 13);
      this.weightLabel.Name = "weightLabel";
      this.weightLabel.Size = new System.Drawing.Size(77, 30);
      this.weightLabel.TabIndex = 0;
      this.weightLabel.Text = "0.00";
      // 
      // enableWeightBox
      // 
      this.enableWeightBox.AutoCheck = false;
      this.enableWeightBox.AutoSize = true;
      this.enableWeightBox.Font = new System.Drawing.Font("宋体", 18F);
      this.enableWeightBox.Location = new System.Drawing.Point(16, 60);
      this.enableWeightBox.Name = "enableWeightBox";
      this.enableWeightBox.Size = new System.Drawing.Size(125, 28);
      this.enableWeightBox.TabIndex = 1;
      this.enableWeightBox.Text = "启用称重";
      this.enableWeightBox.UseVisualStyleBackColor = true;
      // 
      // WeightControl
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.Controls.Add(this.enableWeightBox);
      this.Controls.Add(this.panel1);
      this.Name = "WeightControl";
      this.Size = new System.Drawing.Size(156, 92);
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.Label weightLabel;
    private System.Windows.Forms.CheckBox enableWeightBox;
    private System.IO.Ports.SerialPort weightSerialPort;
  }
}
