﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace BWP.WinFormControl
{
    public static class PrintAPI
    {
        [DllImport("Winpplb.dll")]
        public static extern int B_GetUSBBufferLen();

        [DllImport("Winpplb.dll")]
        public static extern int B_EnumUSB(byte[] buf);

        [DllImport("Winpplb.dll")]
        public static extern int B_CreateUSBPort(int nPort);

        [DllImport("Winpplb.dll")]
        public static extern int B_Set_Direction(char direction);

        [DllImport("Winpplb.dll")]
        public static extern int B_Prn_Text_TrueType(int x, int y, int FSize, string FType,
            int Fspin, int FWeight, int FItalic, int FUnline, int FStrikeOut, string id_name,
            string data);

        [DllImport("Winpplb.dll")]
        public static extern int B_Prn_Barcode(int x, int y, int ori, string type, int narrow,
            int width, int height, char human, string data);

        [DllImport("Winpplb.dll")]
        public static extern int B_Bar2d_QR(int x, int y, int model, int scl, char error,
            char dinput, int c, int d, int p, string data);

        [DllImport("Winpplb.dll")]
        public static extern int B_Print_Out(int labset);

        [DllImport("Winpplb.dll")]
        public static extern void B_ClosePrn();
    }
}
