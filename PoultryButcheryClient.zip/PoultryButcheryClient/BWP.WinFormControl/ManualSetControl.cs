﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  public partial class ManualSetControl : UserControl
  {
    private ManualSet mManualSet;

    //定义委托
    public delegate void ManualSetCheckedChangedHandle(object sender, ManualSetEventArgu e);
    //定义事件
    public event ManualSetCheckedChangedHandle ManualSetCheckedChanged;

    public ManualSetControl(ManualSet manualSet, ManualSetCheckedChangedHandle manualSetCheckedChangedHandle)
    {
      InitializeComponent();
      mManualSet = manualSet;
      ManualSetCheckedChanged = manualSetCheckedChangedHandle;
    }

    public ManualSet ManualSet { get { return mManualSet; } }

    public string CalculateSpec { get { return mManualSet.CalculateSpec_Name; } }

    private void ManualSetControl_Load(object sender, EventArgs e)
    {
      cbxSelected.Checked = mManualSet.IsSelected;
      lblDisplay.Text = mManualSet.CalculateGoods_Name;
    }

    private void cbxSelected_CheckedChanged(object sender, EventArgs e)
    {
     
    }

    private void lblDisplay_Click(object sender, EventArgs e)
    {
      SetClickedBackColor(sender);
    }
    void SetClickedBackColor(object sender)
    {
      this.BackColor = Color.Aqua;
      InvokeManualSetLableClick(sender);
    }

    void InvokeManualSetLableClick(object sender)
    {
      if (ManualSetCheckedChanged == null)
      {
        throw new Exception("没有设置 ManualSetCheckedChanged");
      }

      var argu = new ManualSetEventArgu(mManualSet);
      argu.IsCheckBoxClick = false;
      ManualSetCheckedChanged(sender, argu);
    }

    private void ManualSetControl_Click(object sender, EventArgs e)
    {
      InvokeManualSetLableClick(sender);
    }

    private void cbxSelected_Click(object sender, EventArgs e)
    {
      if (ManualSetCheckedChanged == null)
      {
        throw new Exception("没有设置 ManualSetCheckedChanged");
      }
      this.BackColor = Color.Aqua;

      mManualSet.IsSelected = cbxSelected.Checked;
      var argu = new ManualSetEventArgu(mManualSet);
      argu.IsCheckBoxClick = true;
      ManualSetCheckedChanged(sender, argu);
    }
  }
}
