﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BWP.WinFormControl
{
  /// <summary>
  /// Calendar.xaml 的交互逻辑
  /// </summary>
  public partial class CalendarSelecter : Window, INotifyPropertyChanged
  {
    public CalendarSelecter()
    {
      InitializeComponent();
    }

    public void DragWindow(object sender, MouseButtonEventArgs args)
    {
      this.DragMove();
    }

    private DateTime _result;
    public DateTime Result
    {
      get { return _result; }
      private set { _result = value; OnPropertyChanged("Result"); }
    }

    private void MC_SelectedDatesChanged(object sender, RoutedEventArgs e)
    {
      Result = MC.SelectedDate.Value;
      DialogResult = true;
    }

    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged(string propertyName)
    {
      if (PropertyChanged != null)
        PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
    }

    private void imgToday_Initialized(object sender, EventArgs e)
    {
      Assembly myAssembly = Assembly.GetExecutingAssembly();
      //格式为：项目名称-文件夹地址-文件名称
      Stream myStream = myAssembly.GetManifestResourceStream("BWP.WinFormControl.Images.today.png");
      //图片格式
      BitmapImage image = new BitmapImage();
      image.BeginInit();
      image.StreamSource = myStream;
      image.EndInit();
      myStream.Dispose();
      myStream.Close();

      var imagePanel = (sender as Image);
      imagePanel.Source = image;
    }
  }
}
