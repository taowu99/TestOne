﻿using Forks.JsonRpc.Client;
using Forks.JsonRpc.Client.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BWP.WinFormControl
{
  internal static class ComboBoxHelper
  {
    public static List<WordPair> GetList(string rpc, string input, string codeArg, int range)
    {
      var list = RpcFacade.Call<List<RpcObject>>(rpc, input, codeArg, range);
      var result = new List<WordPair>();
      foreach (var item in list)
      {
        result.Add(new WordPair(item.Get<string>("DisplayName"), item.Get<string>("PhyName")));
      }
      return result;
    }
  }

  public sealed class WordPair
  {
    public string DisplayName { get; private set; }
    public string PhyName { get; private set; }
    public WordPair()
    { }

    public WordPair(string display)
    {
      DisplayName = display;
    }
    public WordPair(string display, string phy)
    {
      DisplayName = display;
      PhyName = phy;
    }

    public override string ToString()
    {
      return DisplayName;
    }
  }
}
