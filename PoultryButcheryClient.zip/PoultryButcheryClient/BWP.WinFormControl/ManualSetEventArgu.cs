﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BWP.WinFormControl
{
public class ManualSetEventArgu : EventArgs
  {
    private ManualSet mManualSet;
    public ManualSetEventArgu(ManualSet manualSet)
    {
      this.mManualSet = manualSet;
    }

    public bool IsSelected 
    {
      get { return mManualSet.IsSelected; }
    }
    public ManualSet ManualSet
    {
      get { return mManualSet; }
    }

    public bool IsCheckBoxClick { get; set; }

  }
}
