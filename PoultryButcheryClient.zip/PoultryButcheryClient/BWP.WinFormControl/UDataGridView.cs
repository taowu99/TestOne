﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  public class UDataGridView : DataGridView
  {
    public UDataGridView()
    {
      this.AllowUserToAddRows = false;
      this.AllowUserToDeleteRows = false;
      this.AllowUserToResizeColumns = false;
      this.AllowUserToResizeRows = false;
      this.BackgroundColor = System.Drawing.Color.White;
      this.ColumnHeadersHeight = 24;
      this.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
      this.MultiSelect = false;

      this.RowHeadersVisible = false;
      this.RowTemplate.Height = 23;
      this.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;

      this.AlternatingRowsDefaultCellStyle = new DataGridViewCellStyle() { BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(235)))), ((int)(((byte)(235))))) };

      this.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle()
      {
        Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft,
        BackColor = System.Drawing.SystemColors.Control,
        Font = new System.Drawing.Font("宋体", 12F),
        ForeColor = System.Drawing.SystemColors.WindowText,
        SelectionBackColor = System.Drawing.SystemColors.Highlight,
        SelectionForeColor = System.Drawing.SystemColors.HighlightText,
        WrapMode = System.Windows.Forms.DataGridViewTriState.True,
      };
      this.RowsDefaultCellStyle = new DataGridViewCellStyle()
      {
        SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(66)))), ((int)(((byte)(163)))), ((int)(((byte)(218))))),
        Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)))
      };
    }
  }
}