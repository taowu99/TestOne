﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BWP.WinFormControl
{
  public class ManualInput
  {
      public string PlanNumber { get; set; }
    public long CalculateGoods_ID { get; set; }
    public string CalculateSpec_Name { get; set; }
    public string CalculateGoods_Name { get; set; }
    public int InputNumber { get; set; }
    public decimal MainUnitRatio { get; set; }

    public decimal SecondUnitII_MainUnitRatio { get; set; }
    public long Goods_ID { get; set; }

    public string DisplayName
    {
      get
      {
        if (!string.IsNullOrWhiteSpace(CalculateSpec_Name))
        {
          return CalculateSpec_Name + "-" + CalculateGoods_Name;
        }
        return CalculateGoods_Name;
      }
    }
  }
}
