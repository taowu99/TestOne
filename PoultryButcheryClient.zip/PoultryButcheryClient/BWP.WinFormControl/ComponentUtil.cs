﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  static class ComponentUtil
  {
    public static Form GetParentFormm(Control control)
    {
      if (control.Parent != null)
      {
        if (control.Parent is Form)
        {
          return control.Parent as Form; ;
        }
        else
        {
          return GetParentFormm(control.Parent);
        }
      }
      return control as Form;
    }
  }
}
