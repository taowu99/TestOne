﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  public partial class ManualInputControl : UserControl
  {
    private ManualInput mManualInput;

    //定义委托
    public delegate void ManualInputClickHandle(object sender, ManualInputEventArgu e);
    //定义事件
    public event ManualInputClickHandle ManualInputClick;

    public ManualInputControl()
    {
      InitializeComponent();
      mManualInput = new ManualInput();
      ManualInputClick = null;
    }
    public ManualInputControl(ManualInput manualInput, ManualInputClickHandle manualInputClickHandle)
    {
      InitializeComponent();
      mManualInput = manualInput;
      ManualInputClick = manualInputClickHandle;
    }

    public ManualInput ManualInput { get { return mManualInput; } }
    public long Goods_ID { get { return mManualInput.CalculateGoods_ID; } }

    private void ManualInputControl_Load(object sender, EventArgs e)
    {
      if (mManualInput.InputNumber > 0)
      {
        btnInput.Text = mManualInput.InputNumber.ToString();
      }
      else
      {
        btnInput.Enabled = false;
      }

      lblDisplay.Text = mManualInput.DisplayName;

    }


    private void btnInput_Click(object sender, EventArgs e)
    {
      this.BackColor = Color.Green;
      Application.DoEvents();
      InvokeManualInputClick(sender,true);
    }

    void InvokeManualInputClick(object sender,bool isButtonClick)
    {
      if (ManualInputClick == null)
      {
        throw new Exception("没有设置ManualInputClickHandler");
      }
      var argu = new ManualInputEventArgu(mManualInput);
      argu.IsButtonClick = isButtonClick;
      ManualInputClick(sender, argu);
    }

    private void ManualInputControl_Click(object sender, EventArgs e)
    {
      SetClickedBackColor(sender);
    }

    private void lblDisplay_Click(object sender, EventArgs e)
    {
      SetClickedBackColor(sender);
    }

    void SetClickedBackColor(object sender)
    {
      this.BackColor = Color.Aqua;
      InvokeManualInputClick(sender, false);
    }

    private Color _clickedBackColor = Color.Aqua;
    [Category("选中背景颜色")]
    [Description("设置或获取选中背景颜色")]
    public Color ClickedBackColor
    {
      get
      {
        return _clickedBackColor;
      }
      set
      {
        _clickedBackColor = value;
      }
    }

    public Label DisplayLable { get { return lblDisplay; } }

//    private void lblDisplay_MouseDown(object sender, MouseEventArgs e)
//    {
//      ManualInputControl_MouseDown(this, e);
//    }
  }
}
