namespace BWP.WinFormControl.WeightDataFormat
{
  public class IND560DataFormat : DataFormatBase {
    public override int DataLength {
      get { return 10; }
    }

    public override char Beginchar {
      get { return (char)0x0A; }//��������û�й̶��Ŀ�ʼ��־
    }

    public override char Endchar {
      get { return (char)0x0D; }
    }

    public override string ParseData(string buf, out bool isStatic)
    {
      isStatic = false;
      return string.Empty;
    }

    public override bool ParseAscii(string buf, out string weight, out bool isStatic) {
      isStatic = true;
      weight = buf.Replace("kg", "").Replace((char)0x0D, (char)0x20).Replace((char)0x0A, (char)0x20);
      weight = weight.Trim();
      return true;
    }

    public override bool ParseAscii(string buf, out string weight, out bool isStatic, out string subStr) {
      weight = "";
      isStatic = false;
      subStr = "";
      return false;
    }
  }
}