﻿namespace BWP.WinFormControl.WeightDataFormat
{
  public interface IDataFormat {
    char Beginchar { get; }
    char Endchar { get; }
    int DataLength { get; }
    bool ParseAscii(string buf, out string weight, out bool isStatic);
    bool ParseAscii(string buf, out string weight, out bool isStatic, out string subStr);
  }

  public abstract class DataFormatBase : IDataFormat {

    public abstract int DataLength {
      get;
    }

    public abstract char Beginchar {
      get;
    }

    public abstract char Endchar {
      get;
    }


    public const short BUFSIZE = 36;
    // 根据开始字符找出 一个完整的数据帧
    public string FindDataFrame(string buf, int fSize) {
      var bufSize = buf.Length;
      if (fSize > bufSize) {
        return string.Empty;
      }

      int index = buf.IndexOf(Beginchar); // 查找开始字符的索引

      if (index < 0 || (index + fSize) > bufSize) {
        return string.Empty;
      }

      string data = buf.Substring(index, fSize);

      // 检查结束字符
      if (data[fSize - 1] != Endchar) {
        return string.Empty;
      }

      return data;
    }

    public abstract string ParseData(string buf, out bool isStatic);

    public abstract bool ParseAscii(string buf, out string weight, out bool isStatic);
    public abstract bool ParseAscii(string buf, out string weight, out bool isStatic, out string subStr);
  }
}
