﻿using System.Text;

namespace BWP.WinFormControl.WeightDataFormat
{
  public class Xk3124DataFormat : DataFormatBase {
    public override int DataLength {
      get { return 17; }
    }

    public override char Beginchar
    {
      get { return (char)0x02; }
    }
     
    public override char Endchar
    {
      get { return (char)0x0D; ; }
    }

    public override string ParseData(string buf, out bool isStatic) {
      StringBuilder str = new StringBuilder();

      char swa = buf[1]; // 状态字A
      char swb = buf[2]; // 状态字B

      int dotIndex = (swa & 0x07) - 2; // 小数点位置

      bool isPositive = (((swb >> 1) & 0x01) == 0); // 符号:是否为正数
      isStatic = (((swb >> 3) & 0x01) == 0);

      char[] num = new char[6];

      for (int i = 0; i < 6; i++) {
        num[i] = buf[i + 4];
      }

      if (dotIndex < 0) { // 不考虑精确到十，百位
        return str.ToString();
      }

      for (int i = 0; i < 6 - dotIndex; i++) {
        str.Append(num[i]);
      }

      str.Append('.');

      for (int i = 0; i < dotIndex; i++) {
        str.Append(num[6 - dotIndex + i]);
      }

      // 去掉空格
      string result = str.ToString().Trim();

      // 取消前面多余的0
      for (int i = 0; i < result.Length; i++) {
        if (result[i] != '0') {
          result = result.Substring(i, result.Length - i);
          break;
        }
      }

      if (result.IndexOf('.') == 0) {
        result = result.Insert(0, "0");
      }

      if (result.IndexOf('.') == result.Length - 1) {
        result = result.Remove(result.IndexOf('.'), 1);
      }

      if (!isPositive) { // 负数
        result = result.Insert(0, "-");
      }

      return result;
    }
     
    public override bool ParseAscii(string buf, out string weight, out bool isStatic) {
      isStatic = false;
      weight = FindDataFrame(buf, DataLength );

      if (string.IsNullOrEmpty(weight)) {
        return false;
      }

      weight = ParseData(weight, out isStatic);

      return true;
    }

    public override bool ParseAscii(string buf, out string weight, out bool isStatic, out string subStr) {
      weight = "";
      isStatic = false;
      subStr = "";
      return false;
    }
  }

  //IND560单次读入
}
