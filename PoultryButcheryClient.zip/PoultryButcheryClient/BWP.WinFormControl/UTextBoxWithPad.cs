﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  public class UTextBoxWithPad: TextBox
  {
    public enum TextBoxType
    {
      Normal,
      Number
    }
    public UTextBoxWithPad()
    {
      this.Font = new Font("宋体", 20);
    }

    public TextBoxType Type { get; set; }

    protected override void OnClick(EventArgs e)
    {
      if (this.Type == TextBoxType.Normal)
      {
        var keyBoard = new VirtualKeyPad();
        if (keyBoard.ShowDialog() == true)
          this.Text = keyBoard.Result;
      }
      else
      {
        var keyBoard = new NumberPad();
        if (keyBoard.ShowDialog() == true)
          this.Text = keyBoard.Result;
      }
      base.OnClick(e);

      var form = ComponentUtil.GetParentFormm(this);
      form.Activate();
      this.Focus();

    }
  }
}
