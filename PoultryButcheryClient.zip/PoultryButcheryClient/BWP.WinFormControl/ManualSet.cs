﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BWP.WinFormControl
{
  public class ManualSet
  {

      public string PlanNumber { get; set; }
    public string FrozenInStoreSet_Name { get; set; }//速冻入库配置

    public string WorkshopCategory_Name { get; set; }//车间分类
    public string CalculateCatalog_Name { get; set; }//分类

    public long? CalculateGoods_ID { get; set; }
    public string CalculateGoods_Name { get; set; }

    public string CalculateSpec_Name { get; set; }//计数规格

    public decimal? MainUnitRatio { get; set; }
    public decimal? SecondUnitII_MainUnitRatio { get; set; }

    public int DefaultNumber1 { get; set; }

    public bool IsSelected { get; set; }
    public long? Goods_ID { get; set; }


    private int mSort = 0;
    public int Sort {
      get { return mSort; }
      set
      {
        if (IsSelected)
        {
          mSort = value;
          if (mSort == -1)
          {
            mSort = 0;
          }
        }
        else
        {
          mSort = -1;
        }
      }
    }

    public string DisplayName
    {
      get
      {
        if (!string.IsNullOrWhiteSpace(CalculateSpec_Name))
        {
          return CalculateSpec_Name + "-" + CalculateGoods_Name;
        }
        return CalculateGoods_Name;
      }
    }
  }
}
