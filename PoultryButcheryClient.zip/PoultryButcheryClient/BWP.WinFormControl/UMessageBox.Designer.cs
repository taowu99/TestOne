﻿namespace BWP.WinFormControl
{
  partial class UMessageBox
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.msgLabel = new System.Windows.Forms.Label();
      this.OKBtn = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // msgLabel
      // 
      this.msgLabel.AutoSize = true;
      this.msgLabel.Font = new System.Drawing.Font("宋体", 15F);
      this.msgLabel.Location = new System.Drawing.Point(83, 38);
      this.msgLabel.Name = "msgLabel";
      this.msgLabel.Size = new System.Drawing.Size(49, 20);
      this.msgLabel.TabIndex = 0;
      this.msgLabel.Text = "消息";
      // 
      // OKBtn
      // 
      this.OKBtn.Font = new System.Drawing.Font("宋体", 15F);
      this.OKBtn.Location = new System.Drawing.Point(111, 112);
      this.OKBtn.Name = "OKBtn";
      this.OKBtn.Size = new System.Drawing.Size(131, 50);
      this.OKBtn.TabIndex = 1;
      this.OKBtn.Text = "确定";
      this.OKBtn.UseVisualStyleBackColor = true;
      this.OKBtn.Click += new System.EventHandler(this.OKBtn_Click);
      // 
      // UMessageBox
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(352, 197);
      this.Controls.Add(this.OKBtn);
      this.Controls.Add(this.msgLabel);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "UMessageBox";
      this.ShowIcon = false;
      this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label msgLabel;
    private System.Windows.Forms.Button OKBtn;
  }
}