﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BWP.WinFormControl
{

  public class ManualInputEventArgu : EventArgs
  {
    private ManualInput manualInput;
    public ManualInputEventArgu(ManualInput manualInput)
    {
      this.manualInput = manualInput;
    }
    public int InputNumber
    {
      get { return manualInput.InputNumber; }
    }
    public ManualInput ManualInput
    {
      get { return manualInput; }
    }

    public bool IsButtonClick { get; set; }

  }
}
