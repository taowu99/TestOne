﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BWP.WinFormControl
{
  public class UDatePicker : Label
  {
    public DateTime? Date
    {
      set
      {
        if (value == null)
        {
          this.Text = string.Empty;
          return;
        }
        var format = "yyyy/MM/dd";
        if (_type == DateTimeType.DateTime)
          format = "yyyy/MM/dd HH:mm:ss";
        this.Text = value.Value.ToString(format);
      }
      get
      {
        if (string.IsNullOrEmpty(this.Text))
          return null;
        return DateTime.Parse(this.Text);
      }
    }

    private DateTimeType _type = DateTimeType.Date;
    public DateTimeType Type
    {
      get { return _type; }
      set { _type = value; }
    }

    public UDatePicker()
    {
      this.BorderStyle = BorderStyle.FixedSingle;
      this.BackColor = Color.White;
      this.Font = new Font("宋体", 15);
      this.TextAlign = ContentAlignment.MiddleLeft;
      this.Text = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
      this.AutoSize = false;
      this.ResumeLayout(false);
    }

    //protected override void InitLayout()
    //{
    //  base.InitLayout();
    //  Date = DateTime.Now;
    //}

    protected override void OnClick(EventArgs e)
    {
      var cs = new CalendarSelecter();
      if (cs.ShowDialog() == true)
      {
        Date = cs.Result + new TimeSpan(DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
      }
    }
  }

  public enum DateTimeType
  {
    Date,
    DateTime
  }
}
