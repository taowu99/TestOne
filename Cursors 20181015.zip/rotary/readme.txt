﻿=== Rotary ⚫ Cursor Set ===

By: AJaxx (http://www.rw-designer.com/user/56600) cyberjack66@yahoo.com

Download: http://www.rw-designer.com/cursor-set/rotary

Author's description:

A fun, legacy CursorXP set ported for windows. Both sizes [32,48] included. Added extra/bonus cursors and animations for user enjoyment.

Credit: This set is from cursorXP which is mostly an obsolete program. It was an old file that I rummaged through and was happy to find that I did not delete it. '''I am not the original author of this set and the link is obsolete therefore concealing the author's identity.''' Unfortunately!

Furthermore, it is a quality set of cursors which the original author made available for free (shared) and, in turn, have been ported for windows and not lost to oblivion.

Have fun & enjoy!
[[cursor:81696]]

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.