﻿=== Qetzal ⚪ Cursor Set ===

By: AJaxx (http://www.rw-designer.com/user/56600) cyberjack66@yahoo.com

Download: http://www.rw-designer.com/cursor-set/qetzal

Author's description:

A fun, Legacy cursorFX set from 2008 ported for windows. Both sizes [32,48] included. Added extra/bonus cursors for user enjoyment.

Credit: DigitalCHET
http://www.wincustomize.com/explore/cursorfx/2354/

Have fun & enjoy!
[[cursor:81696]]

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.