Gruppler's Gruppled Cursors for Windows 
=======================================

Installation
------------
Please note that you will require administrative priveleges on modern Windows OSes.

Both varioations have their own install.ini file so you can choose which, if not both, of the two styles you wish to use.

For each style, right click on the 'install.ini' file and select "install". This should install th cursors to the appropriate place on you system. 

To use the cursors, goto 'Control Panel > Mouse > Pointers'
(note: the instructions are for classic / all items view) and
select either 'Gruppler's Grupppled (Black) Cursors' or 
'Grupplper's Grupppled (White) Cursors'. Enjoy.




Credits
-------
Cursor art by Gruppler
Ported to windows by Furgelnod



Links
-----

Visit furgelnod.deviantart.com for updates, if there ever is any.

Gruppler's cursors and other art can be viewed at gruppler.deviantart.com